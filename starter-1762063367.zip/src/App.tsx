import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { PermitProvider } from './contexts/PermitContext';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import PermitForm from './components/PermitForm';
import PermitRegister from './components/PermitRegister';
import PermitDetails from './components/PermitDetails';
import UserManagement from './components/UserManagement';
import StatusDashboard from './components/StatusDashboard';
import PermitVerification from './components/PermitVerification';
import { Toaster } from './components/ui/toaster';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/" replace />;
}

function App() {
  return (
    <AuthProvider>
      <PermitProvider>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/verify" element={<PermitVerification />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/status-dashboard" element={<StatusDashboard />} />
          <Route path="/new-permit" element={<PermitForm />} />
          <Route path="/edit-permit/:id" element={<PermitForm />} />
          <Route path="/permit/:id" element={<PermitDetails />} />
          <Route path="/register" element={<PermitRegister />} />
          <Route path="/users" element={<UserManagement />} />
        </Routes>
      </PermitProvider>
    </AuthProvider>
  );
}

export default App;