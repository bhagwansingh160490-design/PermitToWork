import { useMemo, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePermits } from '@/contexts/PermitContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Shield, 
  LogOut, 
  Plus, 
  FileText, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Users,
  BookOpen,
  Edit,
  Eye,
  Search,
  Filter
} from 'lucide-react';
import { Permit, PermitStatus } from '@/types/permit';

const STATUS_LABELS: Record<PermitStatus, string> = {
  draft: 'Draft',
  pending_applicant_review: 'Pending Applicant Review',
  pending_issue: 'Pending Issue',
  issued: 'Issued',
  active: 'Active',
  rejected: 'Rejected',
  returned_for_modification: 'Returned for Modification',
  closed: 'Closed',
  expired: 'Expired',
  pending_renewal: 'Pending Renewal'
};

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { permits } = usePermits();
  const navigate = useNavigate();

  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState<string>('all');
  const [filterReceiver, setFilterReceiver] = useState<string>('all');
  const [filterApplicant, setFilterApplicant] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Get unique values for filters
  const uniqueReceivers = useMemo(() => {
    const receivers = new Set(permits.map(p => p.receiverName).filter(Boolean));
    return Array.from(receivers).sort();
  }, [permits]);

  const uniqueApplicants = useMemo(() => {
    const applicants = new Set(permits.map(p => p.applicantName).filter(Boolean));
    return Array.from(applicants).sort();
  }, [permits]);

  // Filter permits
  const filteredPermits = useMemo(() => {
    return permits.filter(permit => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = !searchTerm || 
        (permit.permitNumber || '').toLowerCase().includes(searchLower) ||
        (permit.title || '').toLowerCase().includes(searchLower) ||
        (permit.location || '').toLowerCase().includes(searchLower) ||
        (permit.receiverName || '').toLowerCase().includes(searchLower) ||
        (permit.applicantName && permit.applicantName.toLowerCase().includes(searchLower));

      const matchesDepartment = filterDepartment === 'all' || permit.department === filterDepartment;
      const matchesReceiver = filterReceiver === 'all' || (permit.receiverName && permit.receiverName === filterReceiver);
      const matchesApplicant = filterApplicant === 'all' || (permit.applicantName && permit.applicantName === filterApplicant);
      const matchesStatus = filterStatus === 'all' || permit.status === filterStatus;

      return matchesSearch && matchesDepartment && matchesReceiver && matchesApplicant && matchesStatus;
    }).sort((a, b) => {
      // Get the most recent status change timestamp from approval history
      const getLatestTimestamp = (permit: Permit) => {
        if (permit.approvalHistory && permit.approvalHistory.length > 0) {
          const latestEntry = permit.approvalHistory[permit.approvalHistory.length - 1];
          return new Date(latestEntry.timestamp).getTime();
        }
        return new Date(permit.createdAt).getTime();
      };

      return getLatestTimestamp(b) - getLatestTimestamp(a);
    });
  }, [permits, searchTerm, filterDepartment, filterReceiver, filterApplicant, filterStatus]);

  const stats = useMemo(() => {
    return {
      total: permits.length,
      draft: permits.filter(p => p.status === 'draft').length,
      pending_review: permits.filter(p => p.status === 'pending_applicant_review').length,
      pending_issue: permits.filter(p => p.status === 'pending_issue').length,
      issued: permits.filter(p => p.status === 'issued').length,
      active: permits.filter(p => p.status === 'active').length,
      returned: permits.filter(p => p.status === 'returned_for_modification').length,
      rejected: permits.filter(p => p.status === 'rejected').length,
      expired: permits.filter(p => p.status === 'expired').length,
      closed: permits.filter(p => p.status === 'closed').length,
      pending_renewal: permits.filter(p => p.status === 'pending_renewal').length
    };
  }, [permits]);

  const getStatusBadge = (status: PermitStatus) => {
    const variants: Record<PermitStatus, string> = {
      draft: 'bg-gray-500 text-white',
      pending_applicant_review: 'bg-yellow-500 text-white',
      pending_issue: 'bg-orange-500 text-white',
      issued: 'bg-green-500 text-white',
      active: 'bg-blue-500 text-white',
      returned_for_modification: 'bg-purple-500 text-white',
      rejected: 'bg-red-600 text-white',
      expired: 'bg-red-700 text-white',
      closed: 'bg-gray-600 text-white',
      pending_renewal: 'bg-amber-500 text-white'
    };
    
    return (
      <Badge className={variants[status] || variants.draft}>
        {STATUS_LABELS[status]}
      </Badge>
    );
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterDepartment('all');
    setFilterReceiver('all');
    setFilterApplicant('all');
    setFilterStatus('all');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Permit-to-Work System</h1>
                <p className="text-sm text-gray-600">
                  {user?.name} • {user?.role.charAt(0).toUpperCase() + user?.role.slice(1)}
                  {user?.department && ` • ${user.department} Department`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {user?.role === 'admin' && (
                <Button variant="outline" onClick={() => navigate('/users')}>
                  <Users className="h-4 w-4 mr-2" />
                  Users
                </Button>
              )}
              {(user?.role === 'applicant' || user?.role === 'issuer' || user?.role === 'admin') && (
                <Button variant="outline" onClick={() => navigate('/register')}>
                  <BookOpen className="h-4 w-4 mr-2" />
                  Register
                </Button>
              )}
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Permits</CardDescription>
              <CardTitle className="text-3xl text-blue-600">{stats.total}</CardTitle>
            </CardHeader>
          </Card>
          {stats.draft > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Draft</CardDescription>
                <CardTitle className="text-3xl text-gray-600">{stats.draft}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.pending_review > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Pending Review</CardDescription>
                <CardTitle className="text-3xl text-yellow-600">{stats.pending_review}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.pending_issue > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Pending Issue</CardDescription>
                <CardTitle className="text-3xl text-orange-600">{stats.pending_issue}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.issued > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Issued</CardDescription>
                <CardTitle className="text-3xl text-green-600">{stats.issued}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.active > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Active</CardDescription>
                <CardTitle className="text-3xl text-blue-600">{stats.active}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.pending_renewal > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Pending Renewal</CardDescription>
                <CardTitle className="text-3xl text-amber-600">{stats.pending_renewal}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.returned > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Returned</CardDescription>
                <CardTitle className="text-3xl text-purple-600">{stats.returned}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.rejected > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Rejected</CardDescription>
                <CardTitle className="text-3xl text-red-600">{stats.rejected}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.expired > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Expired</CardDescription>
                <CardTitle className="text-3xl text-red-700">{stats.expired}</CardTitle>
              </CardHeader>
            </Card>
          )}
          {stats.closed > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Closed</CardDescription>
                <CardTitle className="text-3xl text-gray-600">{stats.closed}</CardTitle>
              </CardHeader>
            </Card>
          )}
        </div>

        {/* Action Buttons */}
        {user?.role === 'receiver' && (
          <div className="mb-6">
            <Button size="lg" onClick={() => navigate('/new-permit')}>
              <Plus className="h-5 w-5 mr-2" />
              New Permit Application
            </Button>
            <p className="text-sm text-gray-500 mt-2">
              Note: Permits can only be created for work starting within the next 10 days. Permits older than 10 days are automatically closed.
            </p>
          </div>
        )}

        {/* Search & Filters Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Search & Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="lg:col-span-2">
                <label className="text-sm font-medium mb-2 block">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by permit number, title, location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Department Filter */}
              <div>
                <label className="text-sm font-medium mb-2 block">Department</label>
                <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Departments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    <SelectItem value="Civil">Civil</SelectItem>
                    <SelectItem value="Mechanical">Mechanical</SelectItem>
                    <SelectItem value="Electrical">Electrical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Receiver Filter */}
              <div>
                <label className="text-sm font-medium mb-2 block">Receiver</label>
                <Select value={filterReceiver} onValueChange={setFilterReceiver}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Receivers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Receivers</SelectItem>
                    {uniqueReceivers.map(receiver => (
                      <SelectItem key={receiver} value={receiver}>{receiver}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Applicant Filter */}
              <div>
                <label className="text-sm font-medium mb-2 block">Applicant</label>
                <Select value={filterApplicant} onValueChange={setFilterApplicant}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Applicants" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Applicants</SelectItem>
                    {uniqueApplicants.map(applicant => (
                      <SelectItem key={applicant} value={applicant}>{applicant}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Status Filter */}
              <div className="lg:col-span-3">
                <label className="text-sm font-medium mb-2 block">Permit Status</label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {Object.entries(STATUS_LABELS).map(([status, label]) => (
                      <SelectItem key={status} value={status}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Clear Filters Button */}
              <div className="lg:col-span-2 flex items-end">
                <Button variant="outline" onClick={clearFilters} className="w-full">
                  Clear All Filters
                </Button>
              </div>
            </div>

            {/* Results Count */}
            <div className="mt-4 text-sm text-gray-600">
              Showing <span className="font-semibold">{filteredPermits.length}</span> of <span className="font-semibold">{permits.length}</span> permits
            </div>
          </CardContent>
        </Card>

        {/* Permits Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="font-semibold">Permit Number</TableHead>
                    <TableHead className="font-semibold">Department</TableHead>
                    <TableHead className="font-semibold">Location</TableHead>
                    <TableHead className="font-semibold">Receiver</TableHead>
                    <TableHead className="font-semibold">Applicant</TableHead>
                    <TableHead className="font-semibold">Issuer</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold text-center">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPermits.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-12 text-gray-500">
                        <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No permits found matching your filters</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPermits.map((permit) => (
                      <TableRow key={permit.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium">
                          <div>
                            <div className="font-semibold text-blue-600">{permit.permitNumber || '-'}</div>
                            <div className="text-xs text-gray-500">{permit.title || '-'}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {permit.department ? (
                            <Badge variant="outline">{permit.department}</Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell className="max-w-[200px]">
                          {permit.location ? (
                            <div className="truncate" title={permit.location}>
                              {permit.location}
                            </div>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {permit.receiverName || <span className="text-gray-400">-</span>}
                        </TableCell>
                        <TableCell>
                          {permit.applicantName || <span className="text-gray-400">-</span>}
                        </TableCell>
                        <TableCell>
                          {permit.issuerName || <span className="text-gray-400">-</span>}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(permit.status)}
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/permit/${permit.id}`)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}