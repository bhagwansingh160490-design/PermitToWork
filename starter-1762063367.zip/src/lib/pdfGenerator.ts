import jsPDF from 'jspdf';
import QRCode from 'qrcode';
import { Permit } from '@/types/permit';

export async function generatePermitPDF(permit: Permit | undefined) {
  if (!permit) {
    throw new Error('Permit data is required');
  }

  const doc = new jsPDF();
  
  // Generate QR code linking to verification page with permit number
  const appUrl = window.location.origin;
  const verificationUrl = `${appUrl}/verify?permitNumber=${encodeURIComponent(permit.permitNumber)}`;
  const qrCodeUrl = await QRCode.toDataURL(
    verificationUrl,
    { width: 100, margin: 1 }
  );

  // Logo and Header
  doc.setFillColor(37, 99, 235); // Blue background
  doc.rect(0, 0, 210, 35, 'F');
  
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('PERMIT TO WORK SYSTEM', 105, 15, { align: 'center' });
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text('Electronic Permit Management', 105, 23, { align: 'center' });
  
  // QR Code
  doc.addImage(qrCodeUrl, 'PNG', 170, 5, 25, 25);
  
  doc.setTextColor(0, 0, 0);
  
  let yPos = 45;
  
  // Permit Number and Status
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(`Permit No: ${permit.permitNumber || 'N/A'}`, 20, yPos);
  
  // Status Badge
  const statusColors: Record<string, [number, number, number]> = {
    'active': [34, 197, 94],
    'issued': [59, 130, 246],
    'pending_issue': [251, 191, 36],
    'closed': [107, 114, 128],
    'expired': [239, 68, 68],
    'rejected': [220, 38, 38]
  };
  const color = statusColors[permit.status] || [156, 163, 175];
  doc.setFillColor(color[0], color[1], color[2]);
  doc.roundedRect(150, yPos - 5, 45, 8, 2, 2, 'F');
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text(permit.status.toUpperCase().replace(/_/g, ' '), 172.5, yPos, { align: 'center' });
  doc.setTextColor(0, 0, 0);
  
  yPos += 12;
  
  // Helper function to draw table
  const drawTable = (headers: string[], rows: string[][], startY: number) => {
    const colWidth = 85;
    const rowHeight = 7;
    let currentY = startY;
    
    // Draw rows
    rows.forEach((row, index) => {
      // Alternate row colors
      if (index % 2 === 0) {
        doc.setFillColor(249, 250, 251);
        doc.rect(20, currentY, colWidth * 2, rowHeight, 'F');
      }
      
      // Draw cell borders
      doc.setDrawColor(229, 231, 235);
      doc.rect(20, currentY, colWidth, rowHeight);
      doc.rect(20 + colWidth, currentY, colWidth, rowHeight);
      
      // Draw text
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text(row[0], 22, currentY + 5);
      doc.setFont('helvetica', 'normal');
      const textLines = doc.splitTextToSize(row[1] || 'N/A', colWidth - 4);
      doc.text(textLines, 22 + colWidth, currentY + 5);
      
      currentY += Math.max(rowHeight, textLines.length * 5);
    });
    
    return currentY;
  };
  
  // Basic Information Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setFillColor(243, 244, 246);
  doc.rect(20, yPos, 170, 8, 'F');
  doc.text('BASIC INFORMATION', 22, yPos + 5.5);
  yPos += 10;
  
  const basicInfo = [
    ['Permit Type', permit.type || 'N/A'],
    ['Title', permit.title || 'N/A'],
    ['Department', permit.department || 'N/A'],
    ['Location', permit.location || 'N/A'],
    ['Issue Date', permit.lastIssuedDate ? new Date(permit.lastIssuedDate).toLocaleString() : new Date(permit.createdAt).toLocaleString()],
    ['Expiry Date', permit.expiryDate ? new Date(permit.expiryDate).toLocaleString() : 'N/A']
  ];
  
  yPos = drawTable([], basicInfo, yPos);
  yPos += 5;
  
  // Work Schedule Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setFillColor(243, 244, 246);
  doc.rect(20, yPos, 170, 8, 'F');
  doc.text('WORK SCHEDULE', 22, yPos + 5.5);
  yPos += 10;
  
  const scheduleInfo = [
    ['Work Start Date', permit.workStartDate || 'N/A'],
    ['Work Start Time', permit.workStartTime || 'N/A'],
    ['Expected Completion Date', permit.expectedCompletionDate || 'N/A'],
    ['Expected Completion Time', permit.expectedCompletionTime || 'N/A']
  ];
  
  yPos = drawTable([], scheduleInfo, yPos);
  yPos += 5;
  
  // Work Description Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setFillColor(243, 244, 246);
  doc.rect(20, yPos, 170, 8, 'F');
  doc.text('WORK DESCRIPTION', 22, yPos + 5.5);
  yPos += 10;
  
  const descriptionInfo = [
    ['Description', permit.description || 'N/A'],
    ['Identified Hazards', permit.hazards?.join(', ') || 'None'],
    ['Safety Precautions', permit.precautions || 'N/A'],
    ['Required PPE', permit.requiredPPE?.join(', ') || 'None']
  ];
  
  yPos = drawTable([], descriptionInfo, yPos);
  
  // Check if we need a new page
  if (yPos > 240) {
    doc.addPage();
    yPos = 20;
  } else {
    yPos += 5;
  }
  
  // Personnel Details Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setFillColor(243, 244, 246);
  doc.rect(20, yPos, 170, 8, 'F');
  doc.text('PERSONNEL DETAILS', 22, yPos + 5.5);
  yPos += 10;
  
  const personnelInfo = [
    ['Permit Receiver', permit.receiverName || 'N/A'],
    ['Receiver Department', permit.receiverDepartment || 'N/A'],
    ['Permit Applicant', permit.applicantName || 'N/A'],
    ['Permit Issuer', permit.issuerName || 'N/A'],
    ['Created By', permit.createdBy || 'N/A']
  ];
  
  yPos = drawTable([], personnelInfo, yPos);
  yPos += 5;
  
  // Check if we need a new page
  if (yPos > 240) {
    doc.addPage();
    yPos = 20;
  }
  
  // Renewal History Section
  if (permit.renewalCount && permit.renewalCount > 0 && permit.renewalHistory && permit.renewalHistory.length > 0) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setFillColor(243, 244, 246);
    doc.rect(20, yPos, 170, 8, 'F');
    doc.text(`PERMIT RENEWAL HISTORY (${permit.renewalCount}/7 Renewals)`, 22, yPos + 5.5);
    yPos += 10;
    
    // Draw renewal table header
    doc.setFillColor(229, 231, 235);
    doc.rect(20, yPos, 170, 7, 'F');
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('#', 22, yPos + 5);
    doc.text('Requested', 32, yPos + 5);
    doc.text('Approved', 70, yPos + 5);
    doc.text('Issued', 108, yPos + 5);
    doc.text('Receiver', 146, yPos + 5);
    yPos += 7;
    
    // Draw renewal rows
    doc.setFont('helvetica', 'normal');
    permit.renewalHistory.forEach((renewal, index) => {
      // Check if we need a new page
      if (yPos > 260) {
        doc.addPage();
        yPos = 20;
      }
      
      if (index % 2 === 0) {
        doc.setFillColor(249, 250, 251);
        doc.rect(20, yPos, 170, 14, 'F');
      }
      
      doc.setDrawColor(229, 231, 235);
      doc.rect(20, yPos, 170, 14);
      
      doc.setFontSize(8);
      doc.text(`${renewal.renewalNumber}`, 22, yPos + 4);
      
      // Requested
      doc.text(new Date(renewal.requestedDate).toLocaleDateString(), 32, yPos + 4);
      doc.text(new Date(renewal.requestedDate).toLocaleTimeString(), 32, yPos + 8);
      doc.text(`By: ${renewal.requestedBy}`, 32, yPos + 12);
      
      // Approved
      if (renewal.approvedDate) {
        doc.text(new Date(renewal.approvedDate).toLocaleDateString(), 70, yPos + 4);
        doc.text(new Date(renewal.approvedDate).toLocaleTimeString(), 70, yPos + 8);
        doc.text(`By: ${renewal.approvedBy || 'N/A'}`, 70, yPos + 12);
      } else {
        doc.text('Pending', 70, yPos + 8);
      }
      
      // Issued
      if (renewal.issuedDate) {
        doc.text(new Date(renewal.issuedDate).toLocaleDateString(), 108, yPos + 4);
        doc.text(new Date(renewal.issuedDate).toLocaleTimeString(), 108, yPos + 8);
        doc.text(`By: ${renewal.issuedBy || 'N/A'}`, 108, yPos + 12);
      } else {
        doc.text('Pending', 108, yPos + 8);
      }
      
      // Personnel
      doc.text(`R: ${renewal.receiverName}`, 146, yPos + 4);
      doc.text(`A: ${renewal.applicantName || 'N/A'}`, 146, yPos + 8);
      if (renewal.issuerName) {
        doc.text(`I: ${renewal.issuerName}`, 146, yPos + 12);
      }
      
      yPos += 14;
    });
    
    yPos += 5;
  }
  
  // Approval History Section
  if (permit.approvalHistory && permit.approvalHistory.length > 0) {
    // Check if we need a new page
    if (yPos > 220) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setFillColor(243, 244, 246);
    doc.rect(20, yPos, 170, 8, 'F');
    doc.text('APPROVAL HISTORY', 22, yPos + 5.5);
    yPos += 10;
    
    permit.approvalHistory.forEach((history, index) => {
      // Check if we need a new page
      if (yPos > 260) {
        doc.addPage();
        yPos = 20;
      }
      
      if (index % 2 === 0) {
        doc.setFillColor(249, 250, 251);
      } else {
        doc.setFillColor(255, 255, 255);
      }
      doc.rect(20, yPos, 170, 18, 'F');
      
      doc.setDrawColor(229, 231, 235);
      doc.rect(20, yPos, 170, 18);
      
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text(history.action.replace(/_/g, ' ').toUpperCase(), 22, yPos + 5);
      
      doc.setFont('helvetica', 'normal');
      doc.text(`By: ${history.by} (${history.role})`, 22, yPos + 10);
      doc.text(`Date: ${new Date(history.timestamp).toLocaleString()}`, 22, yPos + 15);
      
      if (history.comments) {
        const commentLines = doc.splitTextToSize(`Comments: ${history.comments}`, 145);
        doc.text(commentLines, 110, yPos + 5);
      }
      
      yPos += 18;
    });
  }
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(128, 128, 128);
    doc.text(
      'This is a digitally generated permit. Scan QR code to verify authenticity.',
      105,
      285,
      { align: 'center' }
    );
    doc.text(`Page ${i} of ${pageCount}`, 105, 290, { align: 'center' });
  }
  
  // Save the PDF
  doc.save(`${permit.permitNumber || 'permit'}.pdf`);
}