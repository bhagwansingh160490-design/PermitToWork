# Git & GitHub Setup Guide

## Overview

This guide provides complete instructions for setting up Git version control and GitHub integration for the Electronic Permit-to-Work System.

## Prerequisites

- Git installed on your system ([Download Git](https://git-scm.com/downloads))
- GitHub account ([Sign up](https://github.com/join))
- Command line access (Terminal, Git Bash, or PowerShell)

## Initial Git Setup

### 1. Configure Git Identity

```bash
# Set your name
git config --global user.name "Your Name"

# Set your email
git config --global user.email "your.email@example.com"

# Verify configuration
git config --list
```

### 2. Initialize Repository

```bash
# Navigate to project directory
cd permit-to-work-system

# Initialize Git repository
git init

# Check status
git status
```

### 3. Create Initial Commit

```bash
# Add all files to staging
git add .

# Create initial commit
git commit -m "Initial commit: Electronic Permit-to-Work System"

# Verify commit
git log
```

## GitHub Integration

### 1. Create GitHub Repository

**Option A: Via GitHub Website**
1. Go to [github.com](https://github.com)
2. Click "New repository"
3. Name: `permit-to-work-system`
4. Description: "Electronic Permit-to-Work System with role-based workflow"
5. Choose Public or Private
6. **DO NOT** initialize with README, .gitignore, or license
7. Click "Create repository"

**Option B: Via GitHub CLI**
```bash
# Install GitHub CLI
# macOS: brew install gh
# Windows: winget install GitHub.cli

# Login
gh auth login

# Create repository
gh repo create permit-to-work-system --public --source=. --remote=origin
```

### 2. Connect Local Repository to GitHub

```bash
# Add remote origin
git remote add origin https://github.com/YOUR_USERNAME/permit-to-work-system.git

# Verify remote
git remote -v

# Push to GitHub
git branch -M main
git push -u origin main
```

### 3. Verify Upload

Visit: `https://github.com/YOUR_USERNAME/permit-to-work-system`

## Branch Management

### Main Branch Protection

```bash
# Create development branch
git checkout -b develop

# Push development branch
git push -u origin develop
```

### Feature Branch Workflow

```bash
# Create feature branch
git checkout -b feature/user-management

# Make changes and commit
git add .
git commit -m "Add user management functionality"

# Push feature branch
git push -u origin feature/user-management

# Create pull request on GitHub
gh pr create --title "Add user management" --body "Implements admin user management features"
```

### Branch Naming Conventions

- `main` - Production-ready code
- `develop` - Development branch
- `feature/feature-name` - New features
- `bugfix/bug-description` - Bug fixes
- `hotfix/critical-fix` - Critical production fixes
- `release/version-number` - Release preparation

## Common Git Commands

### Daily Workflow

```bash
# Check current status
git status

# Pull latest changes
git pull origin main

# Create new branch
git checkout -b feature/new-feature

# Stage changes
git add .
# Or stage specific files
git add src/components/NewComponent.tsx

# Commit changes
git commit -m "Add new component"

# Push changes
git push origin feature/new-feature
```

### Viewing History

```bash
# View commit history
git log

# View compact history
git log --oneline

# View graphical history
git log --graph --oneline --all

# View changes in a commit
git show COMMIT_HASH
```

### Undoing Changes

```bash
# Discard changes in working directory
git checkout -- filename

# Unstage files
git reset HEAD filename

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Undo last commit (discard changes)
git reset --hard HEAD~1

# Revert a commit (creates new commit)
git revert COMMIT_HASH
```

### Stashing Changes

```bash
# Save changes temporarily
git stash

# List stashes
git stash list

# Apply latest stash
git stash apply

# Apply and remove stash
git stash pop

# Clear all stashes
git stash clear
```

## Collaboration Workflow

### Pull Request Process

1. **Create Feature Branch**
   ```bash
   git checkout -b feature/new-feature
   ```

2. **Make Changes and Commit**
   ```bash
   git add .
   git commit -m "Implement new feature"
   ```

3. **Push to GitHub**
   ```bash
   git push origin feature/new-feature
   ```

4. **Create Pull Request**
   - Go to GitHub repository
   - Click "Pull requests" → "New pull request"
   - Select base: `main` and compare: `feature/new-feature`
   - Add title and description
   - Request reviewers
   - Click "Create pull request"

5. **Code Review**
   - Address review comments
   - Make additional commits if needed
   - Push updates to same branch

6. **Merge Pull Request**
   - Once approved, click "Merge pull request"
   - Choose merge strategy (merge commit, squash, rebase)
   - Delete feature branch after merge

### Syncing Forks

```bash
# Add upstream remote
git remote add upstream https://github.com/ORIGINAL_OWNER/permit-to-work-system.git

# Fetch upstream changes
git fetch upstream

# Merge upstream changes
git checkout main
git merge upstream/main

# Push to your fork
git push origin main
```

## Git Best Practices

### Commit Messages

**Format:**
```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting)
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance tasks

**Examples:**
```bash
git commit -m "feat(permits): Add permit renewal functionality"
git commit -m "fix(auth): Resolve login redirect issue"
git commit -m "docs(readme): Update installation instructions"
```

### Commit Frequency

- Commit often with logical changes
- Each commit should be a complete unit of work
- Don't commit broken code
- Don't commit sensitive data (API keys, passwords)

### .gitignore Best Practices

The project `.gitignore` excludes:
- `node_modules/` - Dependencies
- `dist/` - Build output
- `.env*` - Environment variables
- `*.log` - Log files
- `.DS_Store` - OS files
- `tempobook/` - Tempo-specific files
- `.github/` - GitHub workflows (not supported)

## GitHub Features

### Issues

```bash
# Create issue via CLI
gh issue create --title "Bug: Login fails" --body "Description of bug"

# List issues
gh issue list

# View issue
gh issue view 123

# Close issue
gh issue close 123
```

### Projects

1. Go to repository → "Projects"
2. Create new project
3. Add columns: To Do, In Progress, Done
4. Link issues and pull requests
5. Track progress

### Releases

```bash
# Create tag
git tag -a v1.0.0 -m "Release version 1.0.0"

# Push tag
git push origin v1.0.0

# Create release via CLI
gh release create v1.0.0 --title "Version 1.0.0" --notes "Release notes"
```

### GitHub Pages

```bash
# Build project
npm run build

# Deploy to GitHub Pages
# Option 1: Manual
# - Go to Settings → Pages
# - Select branch: main
# - Select folder: /dist
# - Save

# Option 2: Using gh-pages package
npm install --save-dev gh-pages

# Add to package.json scripts:
# "deploy": "gh-pages -d dist"

npm run deploy
```

## Deployment Integration

### Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Link repository
vercel link

# Deploy
vercel --prod
```

**GitHub Integration:**
1. Go to [vercel.com](https://vercel.com)
2. Import Git repository
3. Configure build settings
4. Deploy automatically on push

### Netlify

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Login
netlify login

# Initialize
netlify init

# Deploy
netlify deploy --prod
```

**GitHub Integration:**
1. Go to [netlify.com](https://netlify.com)
2. New site from Git
3. Connect GitHub repository
4. Configure build settings
5. Deploy automatically on push

## Troubleshooting

### Common Issues

**1. Authentication Failed**
```bash
# Use personal access token
git remote set-url origin https://YOUR_TOKEN@github.com/USERNAME/REPO.git

# Or use SSH
git remote set-url origin git@github.com:USERNAME/REPO.git
```

**2. Merge Conflicts**
```bash
# Pull latest changes
git pull origin main

# Resolve conflicts in files
# Look for <<<<<<< HEAD markers

# Stage resolved files
git add .

# Complete merge
git commit -m "Resolve merge conflicts"
```

**3. Accidentally Committed Sensitive Data**
```bash
# Remove from history
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch path/to/file" \
  --prune-empty --tag-name-filter cat -- --all

# Force push
git push origin --force --all
```

**4. Large Files**
```bash
# Use Git LFS for files > 50MB
git lfs install
git lfs track "*.pdf"
git add .gitattributes
git commit -m "Add Git LFS tracking"
```

## Security Best Practices

### Never Commit

- API keys and secrets
- Database credentials
- Environment variables
- Private keys
- User data
- Compiled binaries (unless necessary)

### Use Environment Variables

```bash
# Create .env file (already in .gitignore)
VITE_SUPABASE_URL=your-url
VITE_SUPABASE_ANON_KEY=your-key

# Access in code
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
```

### GitHub Secrets

For CI/CD pipelines:
1. Go to Settings → Secrets and variables → Actions
2. Add repository secrets
3. Use in workflows: `${{ secrets.SECRET_NAME }}`

## Maintenance

### Regular Tasks

**Daily:**
- Pull latest changes
- Commit work in progress
- Push completed features

**Weekly:**
- Review open pull requests
- Update dependencies
- Clean up old branches

**Monthly:**
- Review and close stale issues
- Update documentation
- Create release tags

### Cleanup

```bash
# Delete local branch
git branch -d feature/old-feature

# Delete remote branch
git push origin --delete feature/old-feature

# Prune deleted remote branches
git fetch --prune

# Clean up untracked files
git clean -fd
```

## Resources

### Documentation
- [Git Documentation](https://git-scm.com/doc)
- [GitHub Docs](https://docs.github.com)
- [Git Cheat Sheet](https://education.github.com/git-cheat-sheet-education.pdf)

### Learning
- [GitHub Learning Lab](https://lab.github.com/)
- [Git Branching Game](https://learngitbranching.js.org/)
- [Pro Git Book](https://git-scm.com/book/en/v2)

### Tools
- [GitHub Desktop](https://desktop.github.com/)
- [GitKraken](https://www.gitkraken.com/)
- [SourceTree](https://www.sourcetreeapp.com/)

## Support

For Git/GitHub issues:
1. Check GitHub documentation
2. Search Stack Overflow
3. Ask in GitHub Community
4. Contact repository maintainers

---

**Last Updated**: 2024  
**Git Version**: 2.40+  
**GitHub CLI Version**: 2.40+
