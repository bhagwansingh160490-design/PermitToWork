import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { User } from '@/types/permit';
import { supabase } from '@/lib/supabaseClient';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Rate limiting configuration
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION = 15 * 60 * 1000; // 15 minutes
const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

interface LoginAttempt {
  count: number;
  lastAttempt: number;
  lockedUntil?: number;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loginAttempts, setLoginAttempts] = useState<Map<string, LoginAttempt>>(new Map());
  const [lastActivity, setLastActivity] = useState<number>(Date.now());

  // Session timeout handler
  useEffect(() => {
    if (!user) return;

    const checkSession = () => {
      const now = Date.now();
      if (now - lastActivity > SESSION_TIMEOUT) {
        logout();
        alert('Your session has expired due to inactivity. Please login again.');
      }
    };

    const interval = setInterval(checkSession, 60000); // Check every minute

    // Track user activity
    const updateActivity = () => setLastActivity(Date.now());
    window.addEventListener('mousedown', updateActivity);
    window.addEventListener('keydown', updateActivity);
    window.addEventListener('scroll', updateActivity);
    window.addEventListener('touchstart', updateActivity);

    return () => {
      clearInterval(interval);
      window.removeEventListener('mousedown', updateActivity);
      window.removeEventListener('keydown', updateActivity);
      window.removeEventListener('scroll', updateActivity);
      window.removeEventListener('touchstart', updateActivity);
    };
  }, [user, lastActivity]);

  const login = async (email: string, password: string): Promise<{ success: boolean; message?: string }> => {
    // Input sanitization
    const sanitizedEmail = email.trim().toLowerCase();
    const sanitizedPassword = password.trim();

    // Validate input format
    if (!sanitizedEmail || !sanitizedPassword) {
      return { success: false, message: 'Email and password are required' };
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(sanitizedEmail)) {
      return { success: false, message: 'Invalid email format' };
    }

    // Check rate limiting
    const now = Date.now();
    const attempt = loginAttempts.get(sanitizedEmail) || { count: 0, lastAttempt: 0 };

    // Check if account is locked
    if (attempt.lockedUntil && now < attempt.lockedUntil) {
      const remainingMinutes = Math.ceil((attempt.lockedUntil - now) / 60000);
      return { 
        success: false, 
        message: `Account temporarily locked. Try again in ${remainingMinutes} minute(s)` 
      };
    }

    // Reset attempts if lockout period has passed
    if (attempt.lockedUntil && now >= attempt.lockedUntil) {
      attempt.count = 0;
      attempt.lockedUntil = undefined;
    }

    try {
      // Query user from Supabase
      const { data: foundUser, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', sanitizedEmail)
        .single();

      if (error || !foundUser) {
        // Failed login - increment attempts
        attempt.count += 1;
        attempt.lastAttempt = now;

        if (attempt.count >= MAX_LOGIN_ATTEMPTS) {
          attempt.lockedUntil = now + LOCKOUT_DURATION;
          setLoginAttempts(new Map(loginAttempts.set(sanitizedEmail, attempt)));
          return { 
            success: false, 
            message: `Too many failed attempts. Account locked for 15 minutes` 
          };
        }

        setLoginAttempts(new Map(loginAttempts.set(sanitizedEmail, attempt)));
        const remainingAttempts = MAX_LOGIN_ATTEMPTS - attempt.count;
        return { 
          success: false, 
          message: `Invalid credentials. ${remainingAttempts} attempt(s) remaining` 
        };
      }

      // Check password - for demo, all users have password 'admin123'
      // In production, compare against foundUser.password_hash using bcrypt
      const validPassword = sanitizedPassword === 'admin123';
      
      if (!validPassword) {
        // Failed login - increment attempts
        attempt.count += 1;
        attempt.lastAttempt = now;

        if (attempt.count >= MAX_LOGIN_ATTEMPTS) {
          attempt.lockedUntil = now + LOCKOUT_DURATION;
          setLoginAttempts(new Map(loginAttempts.set(sanitizedEmail, attempt)));
          return { 
            success: false, 
            message: `Too many failed attempts. Account locked for 15 minutes` 
          };
        }

        setLoginAttempts(new Map(loginAttempts.set(sanitizedEmail, attempt)));
        const remainingAttempts = MAX_LOGIN_ATTEMPTS - attempt.count;
        return { 
          success: false, 
          message: `Invalid credentials. ${remainingAttempts} attempt(s) remaining` 
        };
      }
      
      // Successful login - reset attempts
      loginAttempts.delete(sanitizedEmail);
      setLoginAttempts(new Map(loginAttempts));
      
      const userWithoutPassword: User = {
        id: foundUser.id,
        email: foundUser.email,
        name: foundUser.name,
        role: foundUser.role,
        department: foundUser.department
      };
      
      setUser(userWithoutPassword);
      setLastActivity(Date.now());
      return { success: true };
    } catch (err) {
      console.error('Login error:', err);
      return { success: false, message: 'An error occurred during login' };
    }
  };

  const logout = () => {
    setUser(null);
    setLastActivity(Date.now());
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}