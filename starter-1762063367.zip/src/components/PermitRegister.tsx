import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePermits } from '@/contexts/PermitContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Search, Download, Eye } from 'lucide-react';
import { PermitType, Department, PermitStatus } from '@/types/permit';

const STATUS_COLORS: Record<PermitStatus, string> = {
  draft: 'bg-gray-500',
  pending_applicant_review: 'bg-yellow-500',
  pending_issue: 'bg-orange-500',
  issued: 'bg-green-500',
  active: 'bg-green-600',
  rejected: 'bg-red-700',
  returned_for_modification: 'bg-purple-500',
  closed: 'bg-blue-500',
  expired: 'bg-red-500',
  pending_renewal: 'bg-amber-500'
};

const STATUS_LABELS: Record<PermitStatus, string> = {
  draft: 'Draft',
  pending_applicant_review: 'Pending Applicant Review',
  pending_issue: 'Pending Issue',
  issued: 'Issued',
  active: 'Active',
  rejected: 'Rejected',
  returned_for_modification: 'Returned for Modification',
  closed: 'Closed',
  expired: 'Expired',
  pending_renewal: 'Pending Renewal'
};

export default function PermitRegister() {
  const { user } = useAuth();
  const { permits } = usePermits();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterDepartment, setFilterDepartment] = useState<string>('all');

  const filteredPermits = permits.filter(permit => {
    const matchesSearch = 
      permit.permitNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      permit.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      permit.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      permit.receiverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (permit.applicantName && permit.applicantName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (permit.issuerName && permit.issuerName.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = filterStatus === 'all' || permit.status === filterStatus;
    const matchesType = filterType === 'all' || permit.type === filterType;
    const matchesDepartment = filterDepartment === 'all' || permit.department === filterDepartment;

    // Role-based filtering
    if (user?.role === 'receiver') {
      return matchesSearch && matchesStatus && matchesType && matchesDepartment && permit.department === user.department;
    }

    return matchesSearch && matchesStatus && matchesType && matchesDepartment;
  });

  const exportToCSV = () => {
    const headers = [
      'Permit Number',
      'Type',
      'Status',
      'Title',
      'Description',
      'Location',
      'Department',
      'Work Start Date',
      'Work Start Time',
      'Expected Completion Date',
      'Expected Completion Time',
      'Permit Receiver',
      'Permit Applicant',
      'Permit Issuer',
      'Hazards',
      'Precautions',
      'Required PPE',
      'Renewal Count',
      'Created At',
      'Last Issued Date',
      'Closed At',
      'Closed By'
    ];
    
    const rows = filteredPermits.map(p => [
      p.permitNumber,
      p.type,
      STATUS_LABELS[p.status],
      p.title,
      p.description.replace(/,/g, ';'), // Replace commas to avoid CSV issues
      p.location,
      p.department,
      p.workStartDate,
      p.workStartTime,
      p.expectedCompletionDate,
      p.expectedCompletionTime,
      p.receiverName,
      p.applicantName || 'N/A',
      p.issuerName || 'N/A',
      p.hazards.join('; '),
      p.precautions.replace(/,/g, ';'),
      p.requiredPPE.join('; '),
      p.renewalCount || 0,
      new Date(p.createdAt).toLocaleString(),
      p.lastIssuedDate ? new Date(p.lastIssuedDate).toLocaleString() : 'N/A',
      p.closedAt ? new Date(p.closedAt).toLocaleString() : 'N/A',
      p.closedBy || 'N/A'
    ]);

    const csvContent = [
      headers.map(h => `"${h}"`).join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `permit-register-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <Button variant="ghost" onClick={() => navigate('/dashboard')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Permit Register</CardTitle>
              <Button onClick={exportToCSV} variant="outline" disabled={filteredPermits.length === 0}>
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search permits..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="pending_applicant_review">Pending Applicant Review</SelectItem>
                  <SelectItem value="pending_issue">Pending Issue</SelectItem>
                  <SelectItem value="issued">Issued</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="pending_renewal">Pending Renewal</SelectItem>
                  <SelectItem value="returned_for_modification">Returned for Modification</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Cold Work">Cold Work</SelectItem>
                  <SelectItem value="Hot Work">Hot Work</SelectItem>
                  <SelectItem value="Confined Space">Confined Space</SelectItem>
                  <SelectItem value="Working at Height">Working at Height</SelectItem>
                  <SelectItem value="Excavation">Excavation</SelectItem>
                  <SelectItem value="Electrical Work">Electrical Work</SelectItem>
                  <SelectItem value="Lifting Operations">Lifting Operations</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                <SelectTrigger>
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="Civil">Civil</SelectItem>
                  <SelectItem value="Mechanical">Mechanical</SelectItem>
                  <SelectItem value="Electrical">Electrical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Table */}
            <div className="border rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[140px]">Permit Number</TableHead>
                    <TableHead className="min-w-[120px]">Type</TableHead>
                    <TableHead className="min-w-[200px]">Title</TableHead>
                    <TableHead className="min-w-[150px]">Location</TableHead>
                    <TableHead className="min-w-[120px]">Department</TableHead>
                    <TableHead className="min-w-[150px]">Status</TableHead>
                    <TableHead className="min-w-[140px]">Receiver</TableHead>
                    <TableHead className="min-w-[140px]">Applicant</TableHead>
                    <TableHead className="min-w-[140px]">Issuer</TableHead>
                    <TableHead className="min-w-[120px]">Created</TableHead>
                    <TableHead className="min-w-[120px]">Work Start</TableHead>
                    <TableHead className="min-w-[100px]">Renewals</TableHead>
                    <TableHead className="min-w-[100px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPermits.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={13} className="text-center text-gray-500 py-8">
                        No permits found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPermits.map(permit => (
                      <TableRow key={permit.id}>
                        <TableCell className="font-medium">{permit.permitNumber}</TableCell>
                        <TableCell>{permit.type}</TableCell>
                        <TableCell className="max-w-[200px] truncate" title={permit.title}>
                          {permit.title}
                        </TableCell>
                        <TableCell>{permit.location}</TableCell>
                        <TableCell>{permit.department}</TableCell>
                        <TableCell>
                          <Badge className={STATUS_COLORS[permit.status]}>
                            {STATUS_LABELS[permit.status]}
                          </Badge>
                        </TableCell>
                        <TableCell>{permit.receiverName}</TableCell>
                        <TableCell>{permit.applicantName || '-'}</TableCell>
                        <TableCell>{permit.issuerName || '-'}</TableCell>
                        <TableCell>{new Date(permit.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>
                          {permit.workStartDate}
                          <br />
                          <span className="text-xs text-gray-500">{permit.workStartTime}</span>
                        </TableCell>
                        <TableCell className="text-center">
                          {permit.renewalCount || 0}/7
                          {permit.status === 'pending_renewal' && (
                            <Badge variant="outline" className="ml-2 text-amber-600">
                              Needs Renewal
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/permit/${permit.id}`)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="mt-4 text-sm text-gray-600">
              Showing {filteredPermits.length} of {permits.length} permits
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}