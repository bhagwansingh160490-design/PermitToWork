-- Add missing tables if they don't exist

-- Permits Table
CREATE TABLE IF NOT EXISTS permits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    permit_number VARCHAR(50) UNIQUE NOT NULL,
    type VARCHAR(50) NOT NULL CHECK (type IN ('Cold Work', 'Hot Work', 'Confined Space', 'Working at Height', 'Excavation', 'Electrical Work', 'Lifting Operations')),
    status VARCHAR(50) NOT NULL CHECK (status IN ('draft', 'pending_applicant_review', 'pending_issue', 'issued', 'active', 'rejected', 'returned_for_modification', 'closed', 'expired', 'pending_renewal')),
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(255) NOT NULL,
    department VARCHAR(50) NOT NULL CHECK (department IN ('Civil', 'Mechanical', 'Electrical')),
    work_start_date DATE NOT NULL,
    work_start_time TIME NOT NULL,
    expected_completion_date DATE NOT NULL,
    expected_completion_time TIME NOT NULL,
    expiry_date TIMESTAMP WITH TIME ZONE,
    hazards TEXT[],
    precautions TEXT NOT NULL,
    required_ppe TEXT[],
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    receiver_name VARCHAR(255) NOT NULL,
    receiver_department VARCHAR(50) NOT NULL,
    applicant_name VARCHAR(255),
    issuer_name VARCHAR(255),
    rejection_reason TEXT,
    renewal_count INTEGER DEFAULT 0,
    last_renewal_date TIMESTAMP WITH TIME ZONE,
    last_issued_date TIMESTAMP WITH TIME ZONE,
    closed_at TIMESTAMP WITH TIME ZONE,
    closed_by VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Approval History Table
CREATE TABLE IF NOT EXISTS approval_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    permit_id UUID REFERENCES permits(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL CHECK (action IN ('created', 'updated', 'submitted_for_review', 'reviewed', 'submitted_for_issue', 'issued', 'rejected', 'returned', 'closed', 'renewal_requested', 'renewal_approved', 'renewal_issued', 'close_requested', 'close_approved')),
    by_user VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    comments TEXT,
    signature VARCHAR(255),
    renewal_number INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Renewal History Table
CREATE TABLE IF NOT EXISTS renewal_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    permit_id UUID REFERENCES permits(id) ON DELETE CASCADE,
    renewal_number INTEGER NOT NULL,
    requested_date TIMESTAMP WITH TIME ZONE NOT NULL,
    requested_by VARCHAR(255) NOT NULL,
    approved_date TIMESTAMP WITH TIME ZONE,
    approved_by VARCHAR(255),
    issued_date TIMESTAMP WITH TIME ZONE,
    issued_by VARCHAR(255),
    receiver_name VARCHAR(255) NOT NULL,
    applicant_name VARCHAR(255),
    issuer_name VARCHAR(255),
    signature VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Documents Table
CREATE TABLE IF NOT EXISTS permit_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    permit_id UUID REFERENCES permits(id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_type VARCHAR(100),
    file_size INTEGER,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes if they don't exist
CREATE INDEX IF NOT EXISTS idx_permits_status ON permits(status);
CREATE INDEX IF NOT EXISTS idx_permits_permit_number ON permits(permit_number);
CREATE INDEX IF NOT EXISTS idx_permits_created_by ON permits(created_by);
CREATE INDEX IF NOT EXISTS idx_permits_department ON permits(department);
CREATE INDEX IF NOT EXISTS idx_permits_created_at ON permits(created_at);
CREATE INDEX IF NOT EXISTS idx_approval_history_permit_id ON approval_history(permit_id);
CREATE INDEX IF NOT EXISTS idx_renewal_history_permit_id ON renewal_history(permit_id);

-- Enable realtime for all tables
ALTER PUBLICATION supabase_realtime ADD TABLE permits;
ALTER PUBLICATION supabase_realtime ADD TABLE approval_history;
ALTER PUBLICATION supabase_realtime ADD TABLE renewal_history;
ALTER PUBLICATION supabase_realtime ADD TABLE permit_documents;
