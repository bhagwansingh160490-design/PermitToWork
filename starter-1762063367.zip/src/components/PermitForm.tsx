import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePermits } from '@/contexts/PermitContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Upload, Save, Send } from 'lucide-react';
import { PermitType, Department, Permit } from '@/types/permit';

const PERMIT_TYPES: PermitType[] = [
  'Cold Work',
  'Hot Work',
  'Confined Space',
  'Working at Height',
  'Excavation',
  'Electrical Work',
  'Lifting Operations'
];

const DEPARTMENTS: Department[] = ['Civil', 'Mechanical', 'Electrical'];

const COMMON_HAZARDS = [
  'Fire risk',
  'Hot surfaces',
  'Fumes',
  'Confined space',
  'Fall from height',
  'Electrical shock',
  'Heavy lifting',
  'Toxic gases',
  'Oxygen deficiency',
  'Moving machinery'
];

const COMMON_PPE = [
  'Safety helmet',
  'Safety boots',
  'Safety glasses',
  'Gloves',
  'High-visibility vest',
  'Ear protection',
  'Respiratory protection',
  'Fall protection harness',
  'Welding helmet',
  'Heat-resistant gloves'
];

export default function PermitForm() {
  const { user } = useAuth();
  const { addPermit, updatePermit, permits, generateFinalPermitNumber } = usePermits();
  const navigate = useNavigate();
  const { id } = useParams();
  
  // Check if editing existing draft
  const existingPermit = id ? permits.find(p => p.id === id) : null;
  const isEditMode = !!existingPermit;

  // Only permit receivers can create/edit permits
  // Only drafts can be edited
  if (user?.role !== 'receiver') {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-lg text-gray-600">Only Permit Receivers can create new permits.</p>
              <Button onClick={() => navigate('/dashboard')} className="mt-4">
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Prevent editing non-draft permits
  if (isEditMode && existingPermit && existingPermit.status !== 'draft') {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-lg text-gray-600">Only draft permits can be edited.</p>
              <Button onClick={() => navigate('/dashboard')} className="mt-4">
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const [formData, setFormData] = useState({
    type: '' as PermitType | '',
    title: '',
    description: '',
    location: '',
    department: user?.department || '' as Department | '',
    workStartDate: '',
    workStartTime: '',
    expectedCompletionDate: '',
    expectedCompletionTime: '',
    hazards: [] as string[],
    customHazard: '',
    precautions: '',
    requiredPPE: [] as string[],
    customPPE: '',
    receiverName: user?.name || '',
    documents: [] as File[]
  });

  // Load existing permit data if editing
  useEffect(() => {
    if (existingPermit && existingPermit.status === 'draft') {
      setFormData({
        type: existingPermit.type,
        title: existingPermit.title,
        description: existingPermit.description,
        location: existingPermit.location,
        department: existingPermit.department,
        workStartDate: existingPermit.workStartDate,
        workStartTime: existingPermit.workStartTime,
        expectedCompletionDate: existingPermit.expectedCompletionDate,
        expectedCompletionTime: existingPermit.expectedCompletionTime,
        hazards: existingPermit.hazards,
        customHazard: '',
        precautions: existingPermit.precautions,
        requiredPPE: existingPermit.requiredPPE,
        customPPE: '',
        receiverName: existingPermit.receiverName,
        documents: []
      });
    }
  }, [existingPermit]);

  const handleCancel = () => {
    if (confirm('Are you sure you want to cancel? Any unsaved changes will be lost.')) {
      navigate('/dashboard');
    }
  };

  const handleSubmit = async (isDraft: boolean) => {
    // Validate required fields ONLY if submitting (not draft)
    if (!isDraft) {
      // Check all required fields
      if (!formData.type || !formData.title || !formData.description || 
          !formData.location || !formData.department || 
          !formData.workStartDate || !formData.workStartTime ||
          !formData.expectedCompletionDate || !formData.expectedCompletionTime ||
          formData.hazards.length === 0 || !formData.precautions ||
          formData.requiredPPE.length === 0) {
        alert('Please fill in all required fields marked with * before submitting.');
        return;
      }

      // Validate dates
      const workStartDate = new Date(formData.workStartDate);
      const completionDate = new Date(formData.expectedCompletionDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Check if work start date is within 10 days from today
      const daysDiff = Math.floor((workStartDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysDiff > 10) {
        alert('Work start date must be within 10 days from today. Permits can only be created for work starting within the next 10 days.');
        return;
      }

      // Check if completion date is after start date
      if (completionDate < workStartDate) {
        alert('Expected completion date must be on or after the work start date.');
        return;
      }
    }

    try {
      if (isEditMode && existingPermit) {
        // Update existing draft
        const updatedPermit = {
          ...existingPermit,
          type: formData.type as PermitType,
          title: formData.title,
          description: formData.description,
          location: formData.location,
          department: formData.department as Department,
          workStartDate: formData.workStartDate,
          workStartTime: formData.workStartTime,
          expectedCompletionDate: formData.expectedCompletionDate,
          expectedCompletionTime: formData.expectedCompletionTime,
          hazards: formData.hazards,
          precautions: formData.precautions,
          requiredPPE: formData.requiredPPE,
          status: isDraft ? 'draft' : 'pending_applicant_review',
          receiverName: formData.receiverName,
          updatedAt: new Date().toISOString(),
          approvalHistory: [
            ...existingPermit.approvalHistory,
            {
              action: isDraft ? 'updated' : 'submitted_for_review',
              by: user?.name || '',
              role: user?.role || 'receiver',
              timestamp: new Date().toISOString(),
              comments: isDraft ? 'Draft updated' : 'Submitted to applicant for review'
            }
          ]
        };

        await updatePermit(existingPermit.id, updatedPermit);
        alert(`Permit ${isDraft ? 'updated as draft' : 'submitted to applicant for review'} successfully!`);
        navigate('/dashboard');
      } else {
        // Create new permit - ALWAYS use temporary number
        // Final permit number will be assigned by issuer during issuance
        const permitNumber = `DRAFT-${Date.now()}`;
        
        const newPermit: Permit = {
          id: '', // Will be generated by database
          permitNumber,
          type: formData.type as PermitType,
          title: formData.title,
          description: formData.description,
          location: formData.location,
          department: formData.department as Department,
          workStartDate: formData.workStartDate,
          workStartTime: formData.workStartTime,
          expectedCompletionDate: formData.expectedCompletionDate,
          expectedCompletionTime: formData.expectedCompletionTime,
          hazards: formData.hazards,
          precautions: formData.precautions,
          requiredPPE: formData.requiredPPE,
          status: isDraft ? 'draft' : 'pending_applicant_review',
          createdBy: user?.id || '',
          createdAt: new Date().toISOString(),
          receiverName: formData.receiverName,
          receiverDepartment: formData.department as Department,
          renewalCount: 0,
          approvalHistory: [{
            action: isDraft ? 'created' : 'submitted_for_review',
            by: user?.name || '',
            role: user?.role || 'receiver',
            timestamp: new Date().toISOString(),
            comments: isDraft ? 'Draft created' : 'Submitted to applicant for review'
          }]
        };

        await addPermit(newPermit);
        alert(`Permit ${isDraft ? 'saved as draft' : 'submitted to applicant for review'} successfully!`);
        navigate('/dashboard');
      }
    } catch (error: any) {
      console.error('Error submitting permit:', error);
      alert(`Error: ${error.message || 'Failed to submit permit. Please try again.'}`);
    }
  };

  const toggleHazard = (hazard: string) => {
    setFormData(prev => ({
      ...prev,
      hazards: prev.hazards.includes(hazard)
        ? prev.hazards.filter(h => h !== hazard)
        : [...prev.hazards, hazard]
    }));
  };

  const togglePPE = (ppe: string) => {
    setFormData(prev => ({
      ...prev,
      requiredPPE: prev.requiredPPE.includes(ppe)
        ? prev.requiredPPE.filter(p => p !== ppe)
        : [...prev.requiredPPE, ppe]
    }));
  };

  const addCustomHazard = () => {
    if (formData.customHazard.trim()) {
      setFormData(prev => ({
        ...prev,
        hazards: [...prev.hazards, prev.customHazard.trim()],
        customHazard: ''
      }));
    }
  };

  const addCustomPPE = () => {
    if (formData.customPPE.trim()) {
      setFormData(prev => ({
        ...prev,
        requiredPPE: [...prev.requiredPPE, prev.customPPE.trim()],
        customPPE: ''
      }));
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFormData(prev => ({
        ...prev,
        documents: [...prev.documents, ...Array.from(e.target.files!)]
      }));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <Button variant="ghost" onClick={() => navigate('/dashboard')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>{isEditMode ? 'Edit Permit Draft' : 'New Permit Application'}</CardTitle>
            <CardDescription>
              {isEditMode 
                ? 'Update the draft and save or submit to applicant for review.' 
                : 'Complete all required fields to submit. You can save as draft to continue later.'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Permit Type */}
            <div className="space-y-2">
              <Label htmlFor="type">Permit Type *</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value as PermitType }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select permit type" />
                </SelectTrigger>
                <SelectContent>
                  {PERMIT_TYPES.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title">Work Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Brief description of the work"
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Detailed Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Provide detailed information about the work to be performed"
                rows={4}
              />
            </div>

            {/* Location and Department */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="location">Work Location *</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="e.g., Plant Area B, Section 3"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="department">Department *</Label>
                <Select value={formData.department} onValueChange={(value) => setFormData(prev => ({ ...prev, department: value as Department }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    {DEPARTMENTS.map(dept => (
                      <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Work Schedule */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="workStartDate">Start Date *</Label>
                <Input
                  id="workStartDate"
                  type="date"
                  value={formData.workStartDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, workStartDate: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="workStartTime">Start Time *</Label>
                <Input
                  id="workStartTime"
                  type="time"
                  value={formData.workStartTime}
                  onChange={(e) => setFormData(prev => ({ ...prev, workStartTime: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expectedCompletionDate">Expected Completion Date *</Label>
                <Input
                  id="expectedCompletionDate"
                  type="date"
                  value={formData.expectedCompletionDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, expectedCompletionDate: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expectedCompletionTime">Expected Completion Time *</Label>
                <Input
                  id="expectedCompletionTime"
                  type="time"
                  value={formData.expectedCompletionTime}
                  onChange={(e) => setFormData(prev => ({ ...prev, expectedCompletionTime: e.target.value }))}
                />
              </div>
            </div>

            {/* Hazards */}
            <div className="space-y-2">
              <Label>Identified Hazards *</Label>
              <div className="grid grid-cols-2 gap-2">
                {COMMON_HAZARDS.map(hazard => (
                  <div key={hazard} className="flex items-center space-x-2">
                    <Checkbox
                      id={hazard}
                      checked={formData.hazards.includes(hazard)}
                      onCheckedChange={() => toggleHazard(hazard)}
                    />
                    <label htmlFor={hazard} className="text-sm cursor-pointer">{hazard}</label>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-2">
                <Input
                  placeholder="Add custom hazard"
                  value={formData.customHazard}
                  onChange={(e) => setFormData(prev => ({ ...prev, customHazard: e.target.value }))}
                  onKeyPress={(e) => e.key === 'Enter' && addCustomHazard()}
                />
                <Button type="button" onClick={addCustomHazard}>Add</Button>
              </div>
              {formData.hazards.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.hazards.map(hazard => (
                    <Badge key={hazard} variant="secondary">{hazard}</Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Precautions */}
            <div className="space-y-2">
              <Label htmlFor="precautions">Safety Precautions *</Label>
              <Textarea
                id="precautions"
                value={formData.precautions}
                onChange={(e) => setFormData(prev => ({ ...prev, precautions: e.target.value }))}
                placeholder="List all safety precautions and control measures"
                rows={4}
              />
            </div>

            {/* Required PPE */}
            <div className="space-y-2">
              <Label>Required PPE *</Label>
              <div className="grid grid-cols-2 gap-2">
                {COMMON_PPE.map(ppe => (
                  <div key={ppe} className="flex items-center space-x-2">
                    <Checkbox
                      id={ppe}
                      checked={formData.requiredPPE.includes(ppe)}
                      onCheckedChange={() => togglePPE(ppe)}
                    />
                    <label htmlFor={ppe} className="text-sm cursor-pointer">{ppe}</label>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-2">
                <Input
                  placeholder="Add custom PPE"
                  value={formData.customPPE}
                  onChange={(e) => setFormData(prev => ({ ...prev, customPPE: e.target.value }))}
                  onKeyPress={(e) => e.key === 'Enter' && addCustomPPE()}
                />
                <Button type="button" onClick={addCustomPPE}>Add</Button>
              </div>
              {formData.requiredPPE.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.requiredPPE.map(ppe => (
                    <Badge key={ppe} variant="secondary">{ppe}</Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Personnel - Only Receiver Name */}
            <div className="space-y-2">
              <Label htmlFor="receiverName">Receiver Name *</Label>
              <Input
                id="receiverName"
                value={formData.receiverName}
                onChange={(e) => setFormData(prev => ({ ...prev, receiverName: e.target.value }))}
                disabled
              />
            </div>

            {/* Document Upload */}
            <div className="space-y-2">
              <Label htmlFor="documents">Supporting Documents</Label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <Input
                  id="documents"
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <label htmlFor="documents" className="cursor-pointer">
                  <span className="text-blue-600 hover:underline">Click to upload</span>
                  <span className="text-gray-500"> or drag and drop</span>
                </label>
                <p className="text-xs text-gray-500 mt-1">PDF, DOC, JPG up to 10MB</p>
              </div>
              {formData.documents.length > 0 && (
                <div className="mt-2 space-y-1">
                  {formData.documents.map((file, index) => (
                    <div key={index} className="text-sm text-gray-600">
                      📎 {file.name}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={handleCancel} className="flex-1">
                Cancel
              </Button>
              <Button variant="outline" onClick={() => handleSubmit(true)} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </Button>
              <Button onClick={() => handleSubmit(false)} className="flex-1">
                <Send className="h-4 w-4 mr-2" />
                Submit to Applicant
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}