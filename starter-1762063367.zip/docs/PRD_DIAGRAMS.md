# Electronic Permit-to-Work System - PRD Diagram

## System Architecture Diagram

```mermaid
graph TB
    subgraph "User Roles"
        A1[Admin]
        A2[Receiver]
        A3[Applicant]
        A4[Issuer]
    end

    subgraph "Authentication"
        B1[Login Page]
        B2[Supabase Auth]
        B3[Role-Based Access]
    end

    subgraph "Core Features"
        C1[Dashboard]
        C2[Permit Form]
        C3[Permit Details]
        C4[Permit Register]
        C5[User Management]
        C6[QR Verification]
    end

    subgraph "Database - Supabase"
        D1[(Users Table)]
        D2[(Permits Table)]
        D3[(Approval History)]
        D4[(Renewal History)]
        D5[(Documents)]
    end

    A1 --> B1
    A2 --> B1
    A3 --> B1
    A4 --> B1
    
    B1 --> B2
    B2 --> B3
    B3 --> C1
    
    C1 --> C2
    C1 --> C3
    C1 --> C4
    C1 --> C5
    C1 --> C6
    
    C2 --> D2
    C3 --> D2
    C3 --> D3
    C3 --> D4
    C4 --> D2
    C5 --> D1
    C6 --> D2
```

## Permit Workflow Diagram

```mermaid
graph TD
    Start[User Login] --> Dashboard[Dashboard View]
    
    Dashboard --> Action{Select Action}
    
    Action -->|Create Permit| SelectType[Select Work Type]
    Action -->|View Permits| ViewPermits[Permit Register]
    Action -->|Manage Users| UserMgmt[User Management - Admin Only]
    
    SelectType --> WorkTypes{Work Type}
    WorkTypes -->|Cold Work| Form1[Cold Work Form]
    WorkTypes -->|Hot Work| Form2[Hot Work Form]
    WorkTypes -->|Confined Space| Form3[Confined Space Form]
    WorkTypes -->|Working at Height| Form4[Height Work Form]
    WorkTypes -->|Electrical Work| Form5[Electrical Form]
    WorkTypes -->|Excavation| Form6[Excavation Form]
    WorkTypes -->|Lifting Operations| Form7[Lifting Form]
    
    Form1 --> FillForm[Complete Dynamic Fields]
    Form2 --> FillForm
    Form3 --> FillForm
    Form4 --> FillForm
    Form5 --> FillForm
    Form6 --> FillForm
    Form7 --> FillForm
    
    FillForm --> AddDetails[Add Work Details]
    AddDetails --> Hazards[Identify Hazards]
    Hazards --> Precautions[Define Precautions]
    Precautions --> PPE[Select Required PPE]
    PPE --> SaveDraft{Save as Draft?}
    
    SaveDraft -->|Yes| DraftSaved[Draft Saved - DRAFT-timestamp]
    SaveDraft -->|No| SubmitReceiver[Submit to Applicant]
    
    DraftSaved --> Dashboard
    
    SubmitReceiver --> NotifyApplicant[Notify Applicant]
    NotifyApplicant --> ApplicantReview[Applicant Reviews Permit]
    
    ApplicantReview --> ApplicantDecision{Applicant Decision}
    ApplicantDecision -->|Approve| SubmitIssuer[Submit to Issuer]
    ApplicantDecision -->|Reject| RejectReceiver[Return to Receiver]
    ApplicantDecision -->|Request Changes| ModifyReceiver[Request Modifications]
    
    RejectReceiver --> NotifyReceiver1[Notify Receiver]
    ModifyReceiver --> NotifyReceiver1
    NotifyReceiver1 --> Dashboard
    
    SubmitIssuer --> NotifyIssuer[Notify Issuer]
    NotifyIssuer --> IssuerReview[Issuer Reviews Permit]
    
    IssuerReview --> IssuerDecision{Issuer Decision}
    IssuerDecision -->|Issue| GenerateNumber[Generate PTW-YYYY-WW-CCC]
    IssuerDecision -->|Reject| RejectReceiver
    
    GenerateNumber --> DigitalSign[Digital Signature]
    DigitalSign --> PermitIssued[Permit Issued - Status: issued]
    PermitIssued --> GeneratePDF[Generate PDF with QR Code]
    GeneratePDF --> NotifyAll[Notify All Stakeholders]
    NotifyAll --> Active[Permit Active]
    
    Active --> DailyCheck{Daily Status Check}
    
    DailyCheck -->|Next Day| RenewalNeeded[Status: pending_renewal]
    DailyCheck -->|Work Complete| CloseRequest[Close Request]
    DailyCheck -->|10 Days Passed| AutoClose1[Auto-Close by System]
    
    RenewalNeeded --> ReceiverRenewal[Receiver Requests Renewal]
    ReceiverRenewal --> ApplicantRenewal[Applicant Approves Renewal]
    ApplicantRenewal --> IssuerRenewal[Issuer Issues Renewal]
    IssuerRenewal --> CheckRenewalCount{Renewal Count}
    
    CheckRenewalCount -->|< 7| IncrementCount[Increment Count]
    CheckRenewalCount -->|>= 7| AutoClose2[Auto-Close - Max Renewals]
    
    IncrementCount --> Active
    
    CloseRequest --> IssuerClose[Issuer Approves Close]
    IssuerClose --> PermitClosed[Permit Closed]
    
    AutoClose1 --> PermitClosed
    AutoClose2 --> PermitClosed
    
    PermitClosed --> Archive[Archive in Register]
    Archive --> Dashboard
    
    ViewPermits --> FilterPermits[Filter by Status/Type/Dept]
    FilterPermits --> ExportPDF[Export to PDF]
    ExportPDF --> Dashboard
    
    UserMgmt --> ManageUsers{User Action}
    ManageUsers -->|Add| AddUser[Create New User]
    ManageUsers -->|Edit| EditUser[Modify User Details]
    ManageUsers -->|Delete| DeleteUser[Remove User]
    
    AddUser --> Dashboard
    EditUser --> Dashboard
    DeleteUser --> Dashboard
```

## Data Flow Diagram

```mermaid
graph LR
    subgraph "Frontend - React"
        A[Components]
        B[Contexts]
        C[UI Library]
    end
    
    subgraph "State Management"
        D[AuthContext]
        E[PermitContext]
    end
    
    subgraph "API Layer"
        F[Supabase Client]
        G[PDF Generator]
        H[QR Code Generator]
    end
    
    subgraph "Backend - Supabase"
        I[PostgreSQL Database]
        J[Auth Service]
        K[Storage Service]
        L[Realtime Service]
    end
    
    A --> B
    B --> D
    B --> E
    
    D --> F
    E --> F
    
    F --> I
    F --> J
    F --> K
    F --> L
    
    A --> G
    A --> H
    
    G --> PDF[PDF Output]
    H --> QR[QR Code]
```

## Permit Status State Machine

```mermaid
stateDiagram-v2
    [*] --> draft: Receiver creates
    
    draft --> pending_applicant_review: Receiver submits
    draft --> [*]: Delete draft
    
    pending_applicant_review --> pending_issue: Applicant approves
    pending_applicant_review --> returned_for_modification: Applicant requests changes
    pending_applicant_review --> rejected: Applicant rejects
    
    returned_for_modification --> pending_applicant_review: Receiver resubmits
    
    pending_issue --> issued: Issuer issues (PTW number generated)
    pending_issue --> rejected: Issuer rejects
    
    rejected --> [*]: Archive
    
    issued --> pending_renewal: Next day (auto)
    issued --> closed: Manual close
    issued --> expired: 10 days passed
    
    pending_renewal --> issued: Renewal issued (count < 7)
    pending_renewal --> closed: Max renewals reached (count >= 7)
    pending_renewal --> expired: Not renewed in time
    
    closed --> [*]: Archive
    expired --> [*]: Archive
```

## User Role Permissions Matrix

```mermaid
graph TD
    subgraph "Admin Permissions"
        A1[View All Permits]
        A2[Manage Users]
        A3[System Configuration]
        A4[View All Departments]
        A5[Access All Features]
    end
    
    subgraph "Issuer Permissions"
        I1[Issue Permits]
        I2[Reject Permits]
        I3[Issue Renewals]
        I4[Close Permits]
        I5[View Pending Issue]
        I6[Digital Signature]
    end
    
    subgraph "Applicant Permissions"
        AP1[Review Permits]
        AP2[Approve/Reject]
        AP3[Request Modifications]
        AP4[Approve Renewals]
        AP5[View Pending Review]
    end
    
    subgraph "Receiver Permissions"
        R1[Create Permits]
        R2[Submit Permits]
        R3[Request Renewals]
        R4[View Own Permits]
        R5[Edit Drafts]
    end
```

## Database Schema Relationships

```mermaid
erDiagram
    USERS ||--o{ PERMITS : creates
    USERS ||--o{ PERMIT_DOCUMENTS : uploads
    PERMITS ||--o{ APPROVAL_HISTORY : has
    PERMITS ||--o{ RENEWAL_HISTORY : has
    PERMITS ||--o{ PERMIT_DOCUMENTS : contains
    
    USERS {
        uuid id PK
        varchar email UK
        varchar name
        varchar role
        varchar department
        varchar password_hash
        timestamp created_at
        timestamp updated_at
    }
    
    PERMITS {
        uuid id PK
        varchar permit_number UK
        varchar type
        varchar status
        varchar title
        text description
        varchar location
        varchar department
        date work_start_date
        time work_start_time
        date expected_completion_date
        time expected_completion_time
        timestamp expiry_date
        text[] hazards
        text precautions
        text[] required_ppe
        uuid created_by FK
        varchar receiver_name
        varchar applicant_name
        varchar issuer_name
        int renewal_count
        timestamp last_renewal_date
        timestamp last_issued_date
        timestamp created_at
        timestamp updated_at
    }
    
    APPROVAL_HISTORY {
        uuid id PK
        uuid permit_id FK
        varchar action
        varchar by_user
        varchar role
        timestamp timestamp
        text comments
        varchar signature
        int renewal_number
    }
    
    RENEWAL_HISTORY {
        uuid id PK
        uuid permit_id FK
        int renewal_number
        timestamp requested_date
        varchar requested_by
        timestamp approved_date
        varchar approved_by
        timestamp issued_date
        varchar issued_by
        varchar receiver_name
        varchar applicant_name
        varchar issuer_name
    }
    
    PERMIT_DOCUMENTS {
        uuid id PK
        uuid permit_id FK
        varchar file_name
        text file_url
        varchar file_type
        int file_size
        uuid uploaded_by FK
        timestamp uploaded_at
    }
```

## Technology Stack Architecture

```mermaid
graph TB
    subgraph "Frontend Layer"
        F1[React 18.2]
        F2[TypeScript 5.8]
        F3[Vite 6.2]
        F4[Tailwind CSS 3.4]
        F5[ShadCN UI]
        F6[React Router v6]
    end
    
    subgraph "State Management"
        S1[React Context API]
        S2[AuthContext]
        S3[PermitContext]
    end
    
    subgraph "Backend Services"
        B1[Supabase]
        B2[PostgreSQL 14+]
        B3[Supabase Auth]
        B4[Supabase Storage]
        B5[Supabase Realtime]
    end
    
    subgraph "Utilities"
        U1[jsPDF]
        U2[QRCode]
        U3[Lucide Icons]
        U4[Framer Motion]
        U5[React Hook Form]
        U6[Zod Validation]
    end
    
    F1 --> S1
    F2 --> F1
    F3 --> F1
    F4 --> F1
    F5 --> F1
    F6 --> F1
    
    S1 --> S2
    S1 --> S3
    
    S2 --> B1
    S3 --> B1
    
    B1 --> B2
    B1 --> B3
    B1 --> B4
    B1 --> B5
    
    F1 --> U1
    F1 --> U2
    F1 --> U3
    F1 --> U4
    F1 --> U5
    F1 --> U6
```

## Deployment Architecture

```mermaid
graph TB
    subgraph "Development"
        D1[Local Development]
        D2[Vite Dev Server]
        D3[Hot Module Replacement]
    end
    
    subgraph "Version Control"
        V1[Git Repository]
        V2[GitHub]
        V3[Branch Management]
    end
    
    subgraph "Build Process"
        B1[TypeScript Compilation]
        B2[Vite Build]
        B3[Asset Optimization]
        B4[Production Bundle]
    end
    
    subgraph "Deployment Platforms"
        P1[Vercel]
        P2[Netlify]
        P3[Custom Server]
    end
    
    subgraph "Database"
        DB1[Supabase Cloud]
        DB2[PostgreSQL]
        DB3[Automated Backups]
    end
    
    D1 --> D2
    D2 --> D3
    
    D1 --> V1
    V1 --> V2
    V2 --> V3
    
    V2 --> B1
    B1 --> B2
    B2 --> B3
    B3 --> B4
    
    B4 --> P1
    B4 --> P2
    B4 --> P3
    
    P1 --> DB1
    P2 --> DB1
    P3 --> DB1
    
    DB1 --> DB2
    DB2 --> DB3
```

---

**Document Version**: 2.0  
**Last Updated**: 2024  
**Status**: Production Ready
