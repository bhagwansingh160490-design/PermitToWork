-- Function to get ISO week number
CREATE OR REPLACE FUNCTION get_week_number(input_date DATE)
RETURNS INTEGER AS $$
DECLARE
  week_num INTEGER;
BEGIN
  week_num := EXTRACT(WEEK FROM input_date);
  RETURN week_num;
END;
$$ LANGUAGE plpgsql;

-- Function to generate next permit number in PTW-YYYY-WW-CCC format
CREATE OR REPLACE FUNCTION generate_permit_number()
RETURNS TEXT AS $$
DECLARE
  current_year INTEGER;
  current_week INTEGER;
  max_counter INTEGER;
  new_permit_number TEXT;
BEGIN
  current_year := EXTRACT(YEAR FROM CURRENT_DATE);
  current_week := get_week_number(CURRENT_DATE);
  
  -- Find the highest counter for this year and week
  SELECT COALESCE(MAX(
    CAST(SPLIT_PART(permit_number, '-', 4) AS INTEGER)
  ), 0) INTO max_counter
  FROM permits
  WHERE permit_number LIKE 'PTW-' || current_year || '-' || LPAD(current_week::TEXT, 2, '0') || '-%';
  
  -- Increment counter
  max_counter := max_counter + 1;
  
  -- Format: PTW-YYYY-WW-CCC
  new_permit_number := 'PTW-' || 
                       current_year || '-' || 
                       LPAD(current_week::TEXT, 2, '0') || '-' || 
                       LPAD(max_counter::TEXT, 3, '0');
  
  RETURN new_permit_number;
END;
$$ LANGUAGE plpgsql;
