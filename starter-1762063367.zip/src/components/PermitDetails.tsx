import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { usePermits } from '@/contexts/PermitContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ArrowLeft, CheckCircle, XCircle, Download, Printer, Clock, AlertCircle, Edit, RotateCcw, Trash2 } from 'lucide-react';
import { Permit, PermitType, Department, PermitStatus, RenewalRecord } from '@/types/permit';
import { generatePermitPDF } from '@/lib/pdfGenerator';

// Mock permit data
const MOCK_PERMIT = {
  id: '1',
  permitNumber: 'PTW-2024-001',
  type: 'Hot Work' as PermitType,
  title: 'Welding work on pipeline',
  description: 'Welding repairs required on the main pipeline in Plant Area A. Work involves cutting and welding of steel pipes.',
  location: 'Plant Area A, Section 3',
  department: 'Mechanical' as Department,
  status: 'pending_applicant_review',
  createdBy: 'John Receiver',
  createdAt: '2024-01-15T08:00:00Z',
  workStartDate: '2024-01-16',
  workStartTime: '09:00',
  expectedCompletionDate: '2024-01-16',
  expectedCompletionTime: '17:00',
  hazards: ['Fire risk', 'Hot surfaces', 'Fumes'],
  precautions: 'Fire extinguisher on site, fire watch assigned, area cleared of flammable materials, hot work permit displayed.',
  requiredPPE: ['Safety helmet', 'Safety boots', 'Welding helmet', 'Heat-resistant gloves', 'Fire-resistant clothing'],
  receiverName: 'Mike Johnson',
  applicantName: 'John Applicant',
  documents: ['risk-assessment.pdf', 'method-statement.pdf'],
  approvalHistory: [
    {
      action: 'submitted_for_review',
      by: 'Mike Johnson',
      role: 'receiver',
      timestamp: '2024-01-15T08:00:00Z'
    }
  ],
  renewalCount: 0
};

const STATUS_COLORS = {
  draft: 'bg-gray-500',
  pending_applicant_review: 'bg-yellow-500',
  pending_issue: 'bg-orange-500',
  issued: 'bg-green-500',
  active: 'bg-blue-500',
  rejected: 'bg-red-700',
  returned_for_modification: 'bg-purple-500',
  closed: 'bg-gray-600',
  expired: 'bg-red-500',
  pending_renewal: 'bg-amber-500'
};

const STATUS_LABELS = {
  draft: 'Draft',
  pending_applicant_review: 'Pending Applicant Review',
  pending_issue: 'Pending Issue',
  issued: 'Issued',
  active: 'Active',
  rejected: 'Rejected',
  returned_for_modification: 'Returned for Modification',
  closed: 'Closed',
  expired: 'Expired',
  pending_renewal: 'Pending Renewal'
};

export default function PermitDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const { permits, updatePermit, deletePermit, generateFinalPermitNumber } = usePermits();
  const navigate = useNavigate();
  
  // Get permit from context
  const permit = permits.find(p => p.id === id);
  
  const [isEditing, setIsEditing] = useState(false);
  const [editedPermit, setEditedPermit] = useState<Permit | null>(permit || null);
  
  // Update editedPermit when permit changes
  useEffect(() => {
    if (permit) {
      setEditedPermit(permit);
    }
  }, [permit]);

  // Dialogs
  const [showIssueDialog, setShowIssueDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [showReturnDialog, setShowReturnDialog] = useState(false);
  const [showSubmitForIssueDialog, setShowSubmitForIssueDialog] = useState(false);
  const [showRenewalDialog, setShowRenewalDialog] = useState(false);
  const [showCloseDialog, setShowCloseDialog] = useState(false);
  const [showCloseApprovalDialog, setShowCloseApprovalDialog] = useState(false);
  
  const [comments, setComments] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [returnReason, setReturnReason] = useState('');
  const [digitalSignature, setDigitalSignature] = useState('');
  const [closeReason, setCloseReason] = useState('');

  // Update permissions
  const canApplicantReview = user?.role === 'applicant' && permit?.status === 'pending_applicant_review';
  const canApplicantEdit = user?.role === 'applicant' && (permit?.status === 'pending_applicant_review' || permit?.status === 'returned_for_modification');
  const canIssuerAction = user?.role === 'issuer' && permit?.status === 'pending_issue';
  
  // Close permissions - receiver initiates, applicant approves, issuer closes
  const canReceiverInitiateClose = user?.role === 'receiver' && (permit?.status === 'issued' || permit?.status === 'active');
  const canApplicantApproveClose = user?.role === 'applicant' && permit?.status === 'pending_applicant_review' && 
    permit?.approvalHistory?.some(h => h.action === 'close_requested');
  const canIssuerClose = user?.role === 'issuer' && permit?.status === 'pending_issue' && 
    permit?.approvalHistory?.some(h => h.action === 'close_approved');
  
  const canDelete = user?.role === 'admin';
  
  // PDF download available for all users when permit is issued
  const canDownloadPDF = permit?.status === 'issued' || permit?.status === 'active' || permit?.status === 'closed' || permit?.status === 'expired';
  
  // Renewal permissions - receiver initiates, applicant reviews, issuer approves
  const canReceiverRenew = user?.role === 'receiver' && permit?.status === 'pending_renewal';
  const canApplicantRenew = user?.role === 'applicant' && permit?.status === 'pending_applicant_review' && (permit?.renewalCount || 0) > 0;
  const canIssuerRenew = user?.role === 'issuer' && permit?.status === 'pending_issue' && (permit?.renewalCount || 0) > 0;

  // Receiver initiates renewal
  const handleInitiateRenewal = () => {
    if (!id || !permit) return;
    
    const newRenewalNumber = (permit.renewalCount || 0) + 1;
    const newRenewalRecord: RenewalRecord = {
      renewalNumber: newRenewalNumber,
      requestedDate: new Date().toISOString(),
      requestedBy: user?.name || '',
      receiverName: permit.receiverName,
      applicantName: permit.applicantName || '',
    };
    
    updatePermit(id, {
      status: 'pending_applicant_review' as PermitStatus,
      renewalHistory: [...(permit.renewalHistory || []), newRenewalRecord],
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'renewal_requested' as const,
          by: user?.name || '',
          role: 'receiver',
          timestamp: new Date().toISOString(),
          comments: `Renewal ${newRenewalNumber}/7 initiated by receiver`,
          renewalNumber: newRenewalNumber
        }
      ]
    });

    alert('Renewal request submitted to applicant for review!');
    navigate('/dashboard');
  };

  // Applicant approves renewal
  const handleApplicantRenewalApproval = () => {
    if (!id || !permit) return;
    
    const currentRenewalNumber = (permit.renewalCount || 0) + 1;
    const updatedRenewalHistory = [...(permit.renewalHistory || [])];
    const currentRenewal = updatedRenewalHistory[updatedRenewalHistory.length - 1];
    
    if (currentRenewal) {
      currentRenewal.approvedDate = new Date().toISOString();
      currentRenewal.approvedBy = user?.name || '';
      currentRenewal.applicantName = user?.name || '';
    }
    
    updatePermit(id, {
      status: 'pending_issue' as PermitStatus,
      applicantName: user?.name,
      renewalHistory: updatedRenewalHistory,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'renewal_approved' as const,
          by: user?.name || '',
          role: 'applicant',
          timestamp: new Date().toISOString(),
          comments: `Renewal ${currentRenewalNumber}/7 approved by applicant`,
          renewalNumber: currentRenewalNumber
        }
      ]
    });

    alert('Renewal approved and submitted to issuer!');
    setShowSubmitForIssueDialog(false);
    navigate('/dashboard');
  };

  // Issuer issues renewal
  const handleIssueRenewal = async () => {
    if (!digitalSignature.trim()) {
      alert('Please enter your digital signature');
      return;
    }
    if (!id || !permit) return;

    try {
      const newRenewalCount = (permit.renewal_count || 0) + 1;
      const updatedRenewalHistory = [...(permit.renewalHistory || [])];
      const currentRenewal = updatedRenewalHistory[updatedRenewalHistory.length - 1];
      
      if (currentRenewal) {
        currentRenewal.issuedDate = new Date().toISOString();
        currentRenewal.issuedBy = user?.name || '';
        currentRenewal.issuerName = user?.name || '';
        currentRenewal.signature = digitalSignature;
      }

      await updatePermit(id, {
        status: 'issued' as PermitStatus,
        renewalCount: newRenewalCount,
        lastIssuedDate: new Date().toISOString(),
        lastRenewalDate: new Date().toISOString(),
        issuerName: user?.name,
        renewalHistory: updatedRenewalHistory,
        approvalHistory: [
          ...(permit.approvalHistory || []),
          {
            action: 'renewal_issued' as const,
            by: user?.name || '',
            role: 'issuer',
            timestamp: new Date().toISOString(),
            comments: comments || `Renewal ${newRenewalCount}/7 issued`,
            signature: digitalSignature,
            renewalNumber: newRenewalCount
          }
        ]
      });

      alert(`Renewal ${newRenewalCount}/7 issued successfully!`);
      setShowRenewalDialog(false);
      setDigitalSignature('');
      setComments('');
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Error issuing renewal:', error);
      alert(`Error issuing renewal: ${error.message || 'Please try again'}`);
    }
  };

  // Applicant submits for issue
  const handleSubmitForIssue = () => {
    if (!id || !permit) return;
    
    // Check if this is a renewal
    const isRenewal = (permit.renewalCount || 0) > 0;
    
    if (isRenewal) {
      handleApplicantRenewalApproval();
      return;
    }
    
    updatePermit(id, {
      status: 'pending_issue' as PermitStatus,
      applicantName: user?.name,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'submitted_for_issue' as const,
          by: user?.name || '',
          role: user?.role || 'applicant',
          timestamp: new Date().toISOString()
        }
      ]
    });

    alert('Permit submitted to issuer for final approval!');
    setShowSubmitForIssueDialog(false);
    navigate('/dashboard');
  };

  // Issuer issues the permit
  const handleIssue = async () => {
    if (!digitalSignature.trim()) {
      alert('Please enter your digital signature');
      return;
    }
    if (!id || !permit) return;

    // Check if this is a renewal
    const isRenewal = (permit.renewalCount || 0) > 0;
    
    if (isRenewal) {
      handleIssueRenewal();
      return;
    }

    try {
      // Generate final permit number when issuing (async call)
      const finalPermitNumber = await generateFinalPermitNumber();

      await updatePermit(id, {
        permitNumber: finalPermitNumber,
        status: 'issued' as PermitStatus,
        issuerName: user?.name,
        lastIssuedDate: new Date().toISOString(),
        renewalCount: 0,
        approvalHistory: [
          ...(permit.approvalHistory || []),
          {
            action: 'issued' as const,
            by: user?.name || '',
            role: user?.role || 'issuer',
            timestamp: new Date().toISOString(),
            comments: comments || `Permit issued with number ${finalPermitNumber}`,
            signature: digitalSignature
          }
        ]
      });

      alert(`Permit issued successfully with number ${finalPermitNumber}!`);
      setShowIssueDialog(false);
      setDigitalSignature('');
      setComments('');
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Error issuing permit:', error);
      alert(`Error issuing permit: ${error.message || 'Please try again'}`);
    }
  };

  // Issuer rejects the permit
  const handleReject = () => {
    if (!rejectionReason.trim()) {
      alert('Please provide a reason for rejection');
      return;
    }
    if (!id || !permit) return;

    updatePermit(id, {
      status: 'rejected' as PermitStatus,
      rejectionReason,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'rejected' as const,
          by: user?.name || '',
          role: user?.role || 'issuer',
          timestamp: new Date().toISOString(),
          comments: rejectionReason
        }
      ]
    });

    alert('Permit rejected. Applicant will be notified.');
    setShowRejectDialog(false);
    navigate('/dashboard');
  };

  // Issuer returns for modification
  const handleReturn = () => {
    if (!returnReason.trim()) {
      alert('Please provide a reason for returning');
      return;
    }
    if (!id || !permit) return;

    updatePermit(id, {
      status: 'returned_for_modification' as PermitStatus,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'returned' as const,
          by: user?.name || '',
          role: user?.role || 'issuer',
          timestamp: new Date().toISOString(),
          comments: returnReason
        }
      ]
    });

    alert('Permit returned to applicant for modification.');
    setShowReturnDialog(false);
    navigate('/dashboard');
  };

  // Receiver initiates close
  const handleInitiateClose = () => {
    if (!closeReason.trim()) {
      alert('Please provide a reason for closing this permit');
      return;
    }
    if (!id || !permit) return;

    updatePermit(id, {
      status: 'pending_applicant_review' as PermitStatus,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'close_requested' as const,
          by: user?.name || '',
          role: 'receiver',
          timestamp: new Date().toISOString(),
          comments: `Close requested by receiver: ${closeReason}`
        }
      ]
    });

    alert('Close request submitted to applicant for approval!');
    setShowCloseDialog(false);
    setCloseReason('');
    navigate('/dashboard');
  };

  // Applicant approves close
  const handleApplicantCloseApproval = () => {
    if (!id || !permit) return;

    updatePermit(id, {
      status: 'pending_issue' as PermitStatus,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'close_approved' as const,
          by: user?.name || '',
          role: 'applicant',
          timestamp: new Date().toISOString(),
          comments: 'Close request approved by applicant'
        }
      ]
    });

    alert('Close request approved and submitted to issuer!');
    setShowCloseApprovalDialog(false);
    navigate('/dashboard');
  };

  // Issuer finalizes close
  const handleIssuerFinalizeClose = () => {
    if (!digitalSignature.trim()) {
      alert('Please enter your digital signature');
      return;
    }
    if (!id || !permit) return;

    updatePermit(id, {
      status: 'closed' as PermitStatus,
      closedAt: new Date().toISOString(),
      closedBy: user?.name,
      approvalHistory: [
        ...(permit.approvalHistory || []),
        {
          action: 'closed' as const,
          by: user?.name || '',
          role: 'issuer',
          timestamp: new Date().toISOString(),
          comments: comments || 'Permit work completed and closed',
          signature: digitalSignature
        }
      ]
    });

    alert('Permit closed successfully!');
    setShowCloseDialog(false);
    setDigitalSignature('');
    setComments('');
    navigate('/dashboard');
  };

  const handleDelete = () => {
    if (!id) return;
    if (confirm('Are you sure you want to delete this permit? This action cannot be undone.')) {
      deletePermit(id);
      alert('Permit deleted successfully!');
      navigate('/dashboard');
    }
  };

  const handleSaveEdits = () => {
    if (!id || !editedPermit) return;
    updatePermit(id, editedPermit);
    setIsEditing(false);
    alert('Changes saved successfully!');
  };

  const generatePDF = async () => {
    if (!canDownloadPDF) {
      alert('PDF can only be downloaded for issued permits.');
      return;
    }
    try {
      await generatePermitPDF(permit);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  const printPermit = () => {
    window.print();
  };

  if (!permit) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-5xl mx-auto px-4">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-lg text-gray-600">Permit not found</p>
              <Button onClick={() => navigate('/dashboard')} className="mt-4">
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const renewalCount = permit.renewalCount || 0;
  const isRenewal = renewalCount > 0;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4">
        <Button variant="ghost" onClick={() => navigate('/dashboard')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl">{permit.permitNumber}</CardTitle>
                <p className="text-gray-600 mt-1">{permit.title}</p>
                {renewalCount > 0 && (
                  <Badge variant="outline" className="mt-2">
                    Renewal {renewalCount}/7
                  </Badge>
                )}
              </div>
              <Badge className={STATUS_COLORS[permit.status as keyof typeof STATUS_COLORS]}>
                {STATUS_LABELS[permit.status as keyof typeof STATUS_LABELS]}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* PDF Download Notice for Issued Permits */}
            {canDownloadPDF && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-green-900">Permit Issued</p>
                      <p className="text-sm text-green-700">
                        This permit has been issued. All users can view and download the PDF.
                      </p>
                    </div>
                  </div>
                  <Button onClick={generatePDF} className="bg-green-600 hover:bg-green-700">
                    <Download className="h-4 w-4 mr-2" />
                    Download PDF
                  </Button>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2 flex-wrap">
              {canReceiverRenew && (
                <Button onClick={handleInitiateRenewal} className="bg-amber-600 hover:bg-amber-700">
                  <Clock className="h-4 w-4 mr-2" />
                  Initiate Renewal ({renewalCount + 1}/7)
                </Button>
              )}
              {canReceiverInitiateClose && (
                <Button onClick={() => setShowCloseDialog(true)} variant="outline" className="border-red-500 text-red-600 hover:bg-red-50">
                  <Clock className="h-4 w-4 mr-2" />
                  Request Permit Close
                </Button>
              )}
              {canApplicantEdit && !isEditing && (
                <Button onClick={() => setIsEditing(true)} variant="outline">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Details
                </Button>
              )}
              {canApplicantEdit && isEditing && (
                <>
                  <Button onClick={handleSaveEdits}>
                    Save Changes
                  </Button>
                  <Button onClick={() => { setIsEditing(false); setEditedPermit(permit); }} variant="outline">
                    Cancel
                  </Button>
                </>
              )}
              {canApplicantReview && !isEditing && !canApplicantApproveClose && (
                <Button onClick={() => setShowSubmitForIssueDialog(true)} className="bg-blue-600 hover:bg-blue-700">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  {isRenewal ? `Approve Renewal (${renewalCount + 1}/7)` : 'Submit for Issue'}
                </Button>
              )}
              {canApplicantApproveClose && (
                <Button onClick={() => setShowCloseApprovalDialog(true)} className="bg-orange-600 hover:bg-orange-700">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Approve Close Request
                </Button>
              )}
              {canIssuerAction && !canIssuerClose && (
                <>
                  <Button onClick={() => isRenewal ? setShowRenewalDialog(true) : setShowIssueDialog(true)} className="bg-green-600 hover:bg-green-700">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    {isRenewal ? `Issue Renewal (${renewalCount + 1}/7)` : 'Issue Permit'}
                  </Button>
                  <Button onClick={() => setShowReturnDialog(true)} variant="outline">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Return for Modification
                  </Button>
                  <Button onClick={() => setShowRejectDialog(true)} variant="destructive">
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject {isRenewal ? 'Renewal' : 'Permit'}
                  </Button>
                </>
              )}
              {canIssuerClose && (
                <Button onClick={() => setShowCloseDialog(true)} className="bg-red-600 hover:bg-red-700">
                  <Clock className="h-4 w-4 mr-2" />
                  Finalize Permit Close
                </Button>
              )}
              {canDelete && (
                <Button onClick={handleDelete} variant="destructive">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Permit
                </Button>
              )}
              {canDownloadPDF && (
                <Button onClick={generatePDF} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              )}
              <Button onClick={printPermit} variant="outline">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
            </div>

            {/* Renewal Warning */}
            {renewalCount >= 5 && renewalCount < 7 && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-amber-900">Renewal Limit Warning</p>
                    <p className="text-sm text-amber-700">
                      This permit has been renewed {renewalCount} times. Maximum {7 - renewalCount} renewal(s) remaining before automatic closure.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <Separator />

            {/* Permit Details */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-2">Permit Information</h3>
                <dl className="space-y-2 text-sm">
                  <div>
                    <dt className="text-gray-600">Permit Type</dt>
                    <dd className="font-medium">{permit.type}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Department</dt>
                    <dd className="font-medium">{permit.department}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Location</dt>
                    <dd className="font-medium">{isEditing && editedPermit ? (
                      <Input value={editedPermit.location} onChange={(e) => setEditedPermit({...editedPermit, location: e.target.value})} />
                    ) : permit.location}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Created By</dt>
                    <dd className="font-medium">{permit.createdBy}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Created At</dt>
                    <dd className="font-medium">{new Date(permit.createdAt).toLocaleString()}</dd>
                  </div>
                </dl>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Work Schedule</h3>
                <dl className="space-y-2 text-sm">
                  <div>
                    <dt className="text-gray-600">Start Date & Time</dt>
                    <dd className="font-medium">{permit.workStartDate} at {permit.workStartTime}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Expected Completion</dt>
                    <dd className="font-medium">{permit.expectedCompletionDate} at {permit.expectedCompletionTime}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Receiver</dt>
                    <dd className="font-medium">{permit.receiverName}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-600">Applicant</dt>
                    <dd className="font-medium">{permit.applicantName}</dd>
                  </div>
                </dl>
              </div>
            </div>

            <Separator />

            {/* Description */}
            <div>
              <h3 className="font-semibold mb-2">Work Description</h3>
              {isEditing && editedPermit ? (
                <Textarea value={editedPermit.description} onChange={(e) => setEditedPermit({...editedPermit, description: e.target.value})} rows={3} />
              ) : (
                <p className="text-sm text-gray-700">{permit.description}</p>
              )}
            </div>

            <Separator />

            {/* Hazards */}
            <div>
              <h3 className="font-semibold mb-2 flex items-center">
                <AlertCircle className="h-4 w-4 mr-2 text-orange-500" />
                Identified Hazards
              </h3>
              <div className="flex flex-wrap gap-2">
                {permit.hazards.map(hazard => (
                  <Badge key={hazard} variant="destructive">{hazard}</Badge>
                ))}
              </div>
            </div>

            {/* Precautions */}
            <div>
              <h3 className="font-semibold mb-2">Safety Precautions</h3>
              {isEditing && editedPermit ? (
                <Textarea value={editedPermit.precautions} onChange={(e) => setEditedPermit({...editedPermit, precautions: e.target.value})} rows={3} />
              ) : (
                <p className="text-sm text-gray-700">{permit.precautions}</p>
              )}
            </div>

            {/* PPE */}
            <div>
              <h3 className="font-semibold mb-2">Required PPE</h3>
              <div className="flex flex-wrap gap-2">
                {permit.requiredPPE.map(ppe => (
                  <Badge key={ppe} variant="secondary">{ppe}</Badge>
                ))}
              </div>
            </div>

            {/* Documents */}
            {permit.documents && permit.documents.length > 0 && (
              <div>
                <h3 className="font-semibold mb-2">Supporting Documents</h3>
                <div className="space-y-1">
                  {permit.documents.map((doc, index) => (
                    <div key={index} className="text-sm text-blue-600 hover:underline cursor-pointer">
                      📎 {doc}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Approval History */}
            {permit.approvalHistory && permit.approvalHistory.length > 0 && (
              <div>
                <h3 className="font-semibold mb-2">Approval History</h3>
                <div className="space-y-2">
                  {permit.approvalHistory.map((history, index) => (
                    <div key={index} className="text-sm border-l-2 border-blue-500 pl-3 py-1">
                      <p className="font-medium">{history.action.replace(/_/g, ' ').toUpperCase()}</p>
                      <p className="text-gray-600">By: {history.by} ({history.role})</p>
                      <p className="text-gray-500">{new Date(history.timestamp).toLocaleString()}</p>
                      {history.comments && <p className="text-gray-700 mt-1">Comments: {history.comments}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Detailed Renewal History */}
            {permit.renewalHistory && permit.renewalHistory.length > 0 && (
              <div>
                <h3 className="font-semibold mb-2">Detailed Renewal History ({permit.renewalCount}/7)</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border">
                    <thead className="bg-gray-100">
                      <tr>
                        <th className="border px-2 py-2 text-left">Renewal #</th>
                        <th className="border px-2 py-2 text-left">Requested</th>
                        <th className="border px-2 py-2 text-left">Approved</th>
                        <th className="border px-2 py-2 text-left">Issued</th>
                        <th className="border px-2 py-2 text-left">Receiver</th>
                        <th className="border px-2 py-2 text-left">Applicant</th>
                        <th className="border px-2 py-2 text-left">Issuer</th>
                      </tr>
                    </thead>
                    <tbody>
                      {permit.renewalHistory.map((renewal, index) => (
                        <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="border px-2 py-2 font-semibold">#{renewal.renewalNumber}</td>
                          <td className="border px-2 py-2">
                            <div>{new Date(renewal.requestedDate).toLocaleDateString()}</div>
                            <div className="text-xs text-gray-500">{new Date(renewal.requestedDate).toLocaleTimeString()}</div>
                            <div className="text-xs text-gray-600">By: {renewal.requestedBy}</div>
                          </td>
                          <td className="border px-2 py-2">
                            {renewal.approvedDate ? (
                              <>
                                <div>{new Date(renewal.approvedDate).toLocaleDateString()}</div>
                                <div className="text-xs text-gray-500">{new Date(renewal.approvedDate).toLocaleTimeString()}</div>
                                <div className="text-xs text-gray-600">By: {renewal.approvedBy}</div>
                              </>
                            ) : (
                              <Badge variant="outline" className="text-yellow-600">Pending</Badge>
                            )}
                          </td>
                          <td className="border px-2 py-2">
                            {renewal.issuedDate ? (
                              <>
                                <div>{new Date(renewal.issuedDate).toLocaleDateString()}</div>
                                <div className="text-xs text-gray-500">{new Date(renewal.issuedDate).toLocaleTimeString()}</div>
                                <div className="text-xs text-gray-600">By: {renewal.issuedBy}</div>
                              </>
                            ) : (
                              <Badge variant="outline" className="text-yellow-600">Pending</Badge>
                            )}
                          </td>
                          <td className="border px-2 py-2">{renewal.receiverName}</td>
                          <td className="border px-2 py-2">{renewal.applicantName || 'N/A'}</td>
                          <td className="border px-2 py-2">{renewal.issuerName || 'N/A'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Submit for Issue Dialog */}
        <Dialog open={showSubmitForIssueDialog} onOpenChange={setShowSubmitForIssueDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Submit Permit for Issue</DialogTitle>
              <DialogDescription>
                After reviewing all details, submit this permit to the issuer for final approval.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowSubmitForIssueDialog(false)}>Cancel</Button>
              <Button onClick={handleSubmitForIssue} className="bg-blue-600 hover:bg-blue-700">
                Submit to Issuer
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Issue Dialog */}
        <Dialog open={showIssueDialog} onOpenChange={setShowIssueDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Issue Permit</DialogTitle>
              <DialogDescription>
                Please review the permit details and provide your digital signature to issue.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="comments">Comments (Optional)</Label>
                <Textarea
                  id="comments"
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Add any comments or conditions..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="signature">Digital Signature *</Label>
                <Input
                  id="signature"
                  value={digitalSignature}
                  onChange={(e) => setDigitalSignature(e.target.value)}
                  placeholder="Type your full name as signature"
                />
                <p className="text-xs text-gray-500 mt-1">By typing your name, you are digitally signing this permit</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowIssueDialog(false)}>Cancel</Button>
              <Button onClick={handleIssue} className="bg-green-600 hover:bg-green-700">
                Issue Permit
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Renewal Issue Dialog */}
        <Dialog open={showRenewalDialog} onOpenChange={setShowRenewalDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Issue Permit Renewal ({renewalCount + 1}/7)</DialogTitle>
              <DialogDescription>
                Please review the permit details and provide your digital signature to issue this renewal.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="renewal-comments">Comments (Optional)</Label>
                <Textarea
                  id="renewal-comments"
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Add any comments or conditions..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="renewal-signature">Digital Signature *</Label>
                <Input
                  id="renewal-signature"
                  value={digitalSignature}
                  onChange={(e) => setDigitalSignature(e.target.value)}
                  placeholder="Type your full name as signature"
                />
                <p className="text-xs text-gray-500 mt-1">By typing your name, you are digitally signing this renewal</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowRenewalDialog(false)}>Cancel</Button>
              <Button onClick={handleIssueRenewal} className="bg-green-600 hover:bg-green-700">
                Issue Renewal
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rejection Dialog */}
        <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reject Permit</DialogTitle>
              <DialogDescription>
                Please provide a reason for rejecting this permit application.
              </DialogDescription>
            </DialogHeader>
            <div>
              <Label htmlFor="reason">Rejection Reason *</Label>
              <Textarea
                id="reason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Explain why this permit is being rejected..."
                rows={4}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowRejectDialog(false)}>Cancel</Button>
              <Button onClick={handleReject} variant="destructive">
                Reject Permit
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Return for Modification Dialog */}
        <Dialog open={showReturnDialog} onOpenChange={setShowReturnDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Return for Modification</DialogTitle>
              <DialogDescription>
                Return this permit to the applicant for modifications.
              </DialogDescription>
            </DialogHeader>
            <div>
              <Label htmlFor="returnReason">Reason for Return *</Label>
              <Textarea
                id="returnReason"
                value={returnReason}
                onChange={(e) => setReturnReason(e.target.value)}
                placeholder="Explain what needs to be modified..."
                rows={4}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowReturnDialog(false)}>Cancel</Button>
              <Button onClick={handleReturn}>
                Return to Applicant
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Close Request Dialog (Receiver) */}
        <Dialog open={showCloseDialog && canReceiverInitiateClose} onOpenChange={setShowCloseDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Request Permit Close</DialogTitle>
              <DialogDescription>
                Submit a request to close this permit. This will require approval from the applicant and issuer.
              </DialogDescription>
            </DialogHeader>
            <div>
              <Label htmlFor="closeReason">Reason for Closing *</Label>
              <Textarea
                id="closeReason"
                value={closeReason}
                onChange={(e) => setCloseReason(e.target.value)}
                placeholder="Explain why the work is complete and permit should be closed..."
                rows={4}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCloseDialog(false)}>Cancel</Button>
              <Button onClick={handleInitiateClose} className="bg-orange-600 hover:bg-orange-700">
                Submit Close Request
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Close Approval Dialog (Applicant) */}
        <Dialog open={showCloseApprovalDialog} onOpenChange={setShowCloseApprovalDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Approve Close Request</DialogTitle>
              <DialogDescription>
                The receiver has requested to close this permit. Review and approve to send to issuer for final closure.
              </DialogDescription>
            </DialogHeader>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-semibold mb-2">Close Request Details:</p>
              {permit?.approvalHistory
                ?.filter(h => h.action === 'close_requested')
                .map((h, i) => (
                  <div key={i} className="text-sm">
                    <p><strong>Requested by:</strong> {h.by}</p>
                    <p><strong>Date:</strong> {new Date(h.timestamp).toLocaleString()}</p>
                    <p><strong>Reason:</strong> {h.comments}</p>
                  </div>
                ))}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCloseApprovalDialog(false)}>Cancel</Button>
              <Button onClick={handleApplicantCloseApproval} className="bg-blue-600 hover:bg-blue-700">
                Approve & Submit to Issuer
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Close Finalization Dialog (Issuer) */}
        <Dialog open={showCloseDialog && canIssuerClose} onOpenChange={setShowCloseDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Finalize Permit Close</DialogTitle>
              <DialogDescription>
                The receiver and applicant have approved closing this permit. Provide your signature to finalize.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm font-semibold mb-2">Close Approval History:</p>
                {permit?.approvalHistory
                  ?.filter(h => h.action === 'close_requested' || h.action === 'close_approved')
                  .map((h, i) => (
                    <div key={i} className="text-sm mb-2">
                      <p><strong>{h.action === 'close_requested' ? 'Requested' : 'Approved'} by:</strong> {h.by} ({h.role})</p>
                      <p><strong>Date:</strong> {new Date(h.timestamp).toLocaleString()}</p>
                      {h.comments && <p><strong>Comments:</strong> {h.comments}</p>}
                    </div>
                  ))}
              </div>
              <div>
                <Label htmlFor="close-comments">Comments (Optional)</Label>
                <Textarea
                  id="close-comments"
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Add any final comments..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="close-signature">Digital Signature *</Label>
                <Input
                  id="close-signature"
                  value={digitalSignature}
                  onChange={(e) => setDigitalSignature(e.target.value)}
                  placeholder="Type your full name as signature"
                />
                <p className="text-xs text-gray-500 mt-1">By typing your name, you are digitally signing the permit closure</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCloseDialog(false)}>Cancel</Button>
              <Button onClick={handleIssuerFinalizeClose} className="bg-red-600 hover:bg-red-700">
                Close Permit
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}