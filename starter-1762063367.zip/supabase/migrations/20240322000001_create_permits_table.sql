-- Create users table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL,
  department TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default users if they don't exist
INSERT INTO public.users (email, password_hash, full_name, role, department)
VALUES 
  ('admin@ptw.com', '$2a$10$rZ8qKqZ8qKqZ8qKqZ8qKqO', 'Admin User', 'admin', 'Administration'),
  ('receiver@ptw.com', '$2a$10$rZ8qKqZ8qKqZ8qKqZ8qKqO', 'Receiver User', 'receiver', 'Safety'),
  ('applicant@ptw.com', '$2a$10$rZ8qKqZ8qKqZ8qKqZ8qKqO', 'Applicant User', 'applicant', 'Operations'),
  ('issuer@ptw.com', '$2a$10$rZ8qKqZ8qKqZ8qKqZ8qKqO', 'Issuer User', 'issuer', 'Safety')
ON CONFLICT (email) DO NOTHING;

-- Create permits table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.permits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  permit_number TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  location TEXT NOT NULL,
  department TEXT NOT NULL,
  work_start_date DATE NOT NULL,
  work_start_time TIME NOT NULL,
  expected_completion_date DATE NOT NULL,
  expected_completion_time TIME NOT NULL,
  expiry_date TIMESTAMPTZ,
  hazards TEXT[],
  precautions TEXT NOT NULL,
  required_ppe TEXT[],
  created_by UUID REFERENCES public.users(id),
  receiver_name TEXT NOT NULL,
  receiver_department TEXT NOT NULL,
  applicant_name TEXT,
  issuer_name TEXT,
  rejection_reason TEXT,
  renewal_count INTEGER DEFAULT 0,
  last_renewal_date TIMESTAMPTZ,
  last_issued_date TIMESTAMPTZ,
  closed_at TIMESTAMPTZ,
  closed_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable realtime for all tables
ALTER PUBLICATION supabase_realtime ADD TABLE users;
ALTER PUBLICATION supabase_realtime ADD TABLE permits;
ALTER PUBLICATION supabase_realtime ADD TABLE approval_history;
ALTER PUBLICATION supabase_realtime ADD TABLE renewal_history;
ALTER PUBLICATION supabase_realtime ADD TABLE permit_documents;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_permits_status ON public.permits(status);
CREATE INDEX IF NOT EXISTS idx_permits_created_by ON public.permits(created_by);
CREATE INDEX IF NOT EXISTS idx_permits_department ON public.permits(department);