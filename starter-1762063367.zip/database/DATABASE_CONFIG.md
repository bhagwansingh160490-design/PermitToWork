# Database Configuration Guide

## Overview

The Electronic Permit-to-Work System uses **Supabase** (PostgreSQL) as its database backend. This document provides complete configuration details, migration instructions, and maintenance procedures.

## Database Architecture

### Tables

#### 1. users
Stores user accounts with role-based access control.

```sql
Columns:
- id (UUID, PK) - Unique user identifier
- email (VARCHAR, UNIQUE) - User email address
- name (VARCHAR) - Full name
- role (VARCHAR) - User role: receiver, applicant, issuer, admin
- department (VARCHAR) - Civil, Mechanical, or Electrical
- password_hash (VARCHAR) - Hashed password
- created_at (TIMESTAMP) - Account creation date
- updated_at (TIMESTAMP) - Last update timestamp

Indexes:
- idx_users_email (email)
- idx_users_role (role)
```

#### 2. permits
Main table storing all permit information.

```sql
Columns:
- id (UUID, PK) - Unique permit identifier
- permit_number (VARCHAR, UNIQUE) - PTW-YYYY-WW-CCC format
- type (VARCHAR) - Work type (7 types supported)
- status (VARCHAR) - Current permit status
- title (VARCHAR) - Permit title
- description (TEXT) - Work description
- location (VARCHAR) - Work location
- department (VARCHAR) - Responsible department
- work_start_date (DATE) - Scheduled start date
- work_start_time (TIME) - Scheduled start time
- expected_completion_date (DATE) - Expected end date
- expected_completion_time (TIME) - Expected end time
- expiry_date (TIMESTAMP) - Permit expiration
- hazards (TEXT[]) - Array of identified hazards
- precautions (TEXT) - Safety precautions
- required_ppe (TEXT[]) - Required personal protective equipment
- created_by (UUID, FK) - User who created permit
- receiver_name (VARCHAR) - Permit receiver name
- receiver_department (VARCHAR) - Receiver's department
- applicant_name (VARCHAR) - Applicant who reviewed
- issuer_name (VARCHAR) - Issuer who authorized
- rejection_reason (TEXT) - Reason if rejected
- renewal_count (INTEGER) - Number of renewals (0-7)
- last_renewal_date (TIMESTAMP) - Last renewal timestamp
- last_issued_date (TIMESTAMP) - Last issuance timestamp
- closed_at (TIMESTAMP) - Closure timestamp
- closed_by (VARCHAR) - Who closed the permit
- created_at (TIMESTAMP) - Creation timestamp
- updated_at (TIMESTAMP) - Last update timestamp

Indexes:
- idx_permits_status (status)
- idx_permits_permit_number (permit_number)
- idx_permits_created_by (created_by)
- idx_permits_department (department)
- idx_permits_created_at (created_at)

Constraints:
- type CHECK: 7 valid work types
- status CHECK: 10 valid statuses
- department CHECK: 3 valid departments
```

#### 3. approval_history
Tracks all workflow actions and approvals.

```sql
Columns:
- id (UUID, PK) - Unique history record
- permit_id (UUID, FK) - Reference to permit
- action (VARCHAR) - Action type (13 types)
- by_user (VARCHAR) - User who performed action
- role (VARCHAR) - User's role at time of action
- timestamp (TIMESTAMP) - When action occurred
- comments (TEXT) - Optional comments
- signature (VARCHAR) - Digital signature
- renewal_number (INTEGER) - Renewal number if applicable
- created_at (TIMESTAMP) - Record creation

Indexes:
- idx_approval_history_permit_id (permit_id)

Actions:
- created, updated, submitted_for_review
- reviewed, submitted_for_issue, issued
- rejected, returned, closed
- renewal_requested, renewal_approved, renewal_issued
- close_requested, close_approved
```

#### 4. renewal_history
Detailed tracking of permit renewals.

```sql
Columns:
- id (UUID, PK) - Unique renewal record
- permit_id (UUID, FK) - Reference to permit
- renewal_number (INTEGER) - Renewal sequence (1-7)
- requested_date (TIMESTAMP) - When renewal requested
- requested_by (VARCHAR) - Receiver who requested
- approved_date (TIMESTAMP) - When applicant approved
- approved_by (VARCHAR) - Applicant who approved
- issued_date (TIMESTAMP) - When issuer issued
- issued_by (VARCHAR) - Issuer who issued
- receiver_name (VARCHAR) - Receiver for this renewal
- applicant_name (VARCHAR) - Applicant for this renewal
- issuer_name (VARCHAR) - Issuer for this renewal
- signature (VARCHAR) - Digital signature
- created_at (TIMESTAMP) - Record creation

Indexes:
- idx_renewal_history_permit_id (permit_id)
```

#### 5. permit_documents
Stores references to uploaded permit documents.

```sql
Columns:
- id (UUID, PK) - Unique document identifier
- permit_id (UUID, FK) - Reference to permit
- file_name (VARCHAR) - Original filename
- file_url (TEXT) - Storage URL
- file_type (VARCHAR) - MIME type
- file_size (INTEGER) - File size in bytes
- uploaded_by (UUID, FK) - User who uploaded
- uploaded_at (TIMESTAMP) - Upload timestamp
```

## Database Functions

### 1. update_updated_at_column()
Automatically updates the `updated_at` timestamp on record modification.

```sql
Triggers:
- update_users_updated_at (on users table)
- update_permits_updated_at (on permits table)
```

### 2. generate_permit_number()
Generates standardized permit numbers in PTW-YYYY-WW-CCC format.

```sql
Logic:
1. Extract current year (YYYY)
2. Calculate ISO week number (WW)
3. Count permits issued in current week
4. Increment counter (CCC)
5. Return formatted string

Example: PTW-2024-51-001
```

### 3. auto_close_old_permits()
Automatically closes permits older than 10 days.

```sql
Conditions:
- Status: issued, active, or pending_renewal
- Created more than 10 days ago
- Not already closed

Action:
- Set status to 'closed'
- Set closed_at to current timestamp
- Set closed_by to 'System Auto-Close'
```

### 4. check_daily_renewals()
Checks for permits requiring daily renewal.

```sql
Logic:
1. Find permits issued yesterday
2. Set status to 'pending_renewal'
3. Auto-close permits with 7+ renewals

Conditions:
- Status: issued
- Last issued date < current date
- Renewal count < 7
```

## Migration Files

### Execution Order

1. **20240101000000_initial_schema.sql**
   - Creates all tables
   - Sets up indexes
   - Creates functions and triggers
   - Inserts default users

2. **20240322000001_create_permits_table.sql**
   - Enhanced permits table structure
   - Additional constraints

3. **20240322000002_add_missing_tables.sql**
   - Approval history table
   - Renewal history table
   - Additional indexes

4. **20240322000003_add_demo_permits.sql**
   - Sample permit data
   - Test scenarios

5. **20240322000004_permit_number_function.sql**
   - Permit number generation function
   - Auto-numbering logic

### Running Migrations

#### Option 1: Supabase Dashboard
1. Go to SQL Editor in Supabase dashboard
2. Copy contents of each migration file
3. Execute in order
4. Verify success

#### Option 2: Supabase CLI
```bash
# Install Supabase CLI
npm install -g supabase

# Login
supabase login

# Link project
supabase link --project-ref your-project-ref

# Run migrations
supabase db push
```

## Environment Configuration

### Required Variables

```bash
# Frontend (Vite)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Backend/Admin
SUPABASE_PROJECT_ID=your-project-id
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-role-key
```

### Getting Credentials

1. Go to Supabase Dashboard
2. Select your project
3. Navigate to Settings → API
4. Copy:
   - Project URL → SUPABASE_URL
   - Project ID → SUPABASE_PROJECT_ID
   - anon/public key → SUPABASE_ANON_KEY
   - service_role key → SUPABASE_SERVICE_KEY

## Security Configuration

### Row Level Security (RLS)

Enable RLS for production:

```sql
-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE permits ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE renewal_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE permit_documents ENABLE ROW LEVEL SECURITY;

-- Example policies
CREATE POLICY "Users can view own data"
ON users FOR SELECT
USING (auth.uid() = id);

CREATE POLICY "Users can view permits in their department"
ON permits FOR SELECT
USING (
  department = (SELECT department FROM users WHERE id = auth.uid())
  OR
  (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
);
```

### Authentication

Supabase Auth is configured for:
- Email/password authentication
- Session management
- JWT tokens
- Role-based access control

## Backup & Maintenance

### Automated Backups

Supabase provides:
- Daily automated backups (Pro plan)
- Point-in-time recovery
- Manual backup triggers

### Manual Backup

```bash
# Using Supabase CLI
supabase db dump -f backup.sql

# Restore
supabase db reset
psql -h db.your-project.supabase.co -U postgres -d postgres -f backup.sql
```

### Maintenance Tasks

#### Daily
- Run `check_daily_renewals()` function
- Monitor permit expiration

#### Weekly
- Run `auto_close_old_permits()` function
- Review approval history

#### Monthly
- Database performance analysis
- Index optimization
- Archive old permits

## Performance Optimization

### Indexes

All critical columns are indexed:
- Primary keys (UUID)
- Foreign keys
- Status fields
- Date fields
- Email addresses

### Query Optimization

```sql
-- Use indexes for filtering
SELECT * FROM permits WHERE status = 'issued';

-- Use joins efficiently
SELECT p.*, u.name 
FROM permits p
JOIN users u ON p.created_by = u.id
WHERE p.department = 'Civil';

-- Limit results
SELECT * FROM permits 
ORDER BY created_at DESC 
LIMIT 50;
```

### Connection Pooling

Supabase automatically handles connection pooling:
- Max connections: 15 (Free tier)
- Max connections: 60+ (Pro tier)
- Automatic scaling

## Monitoring

### Supabase Dashboard

Monitor:
- Database size
- Active connections
- Query performance
- API usage
- Error logs

### Custom Monitoring

```sql
-- Check permit statistics
SELECT status, COUNT(*) 
FROM permits 
GROUP BY status;

-- Check renewal distribution
SELECT renewal_count, COUNT(*) 
FROM permits 
WHERE status != 'draft'
GROUP BY renewal_count;

-- Check user activity
SELECT role, COUNT(*) 
FROM users 
GROUP BY role;
```

## Troubleshooting

### Common Issues

1. **Connection Errors**
   - Verify environment variables
   - Check Supabase project status
   - Verify API keys

2. **Migration Failures**
   - Check SQL syntax
   - Verify table dependencies
   - Run migrations in order

3. **Performance Issues**
   - Check index usage
   - Optimize queries
   - Review connection pool

4. **Data Integrity**
   - Verify foreign key constraints
   - Check trigger execution
   - Review audit logs

## Support

For database issues:
1. Check Supabase documentation
2. Review migration logs
3. Contact Supabase support
4. Open GitHub issue

---

**Last Updated**: 2024  
**Database Version**: PostgreSQL 14+  
**Supabase Version**: 2.76+
