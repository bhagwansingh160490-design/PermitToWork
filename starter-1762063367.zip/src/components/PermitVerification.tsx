import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePermits } from '@/contexts/PermitContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ShieldCheck, AlertCircle, ArrowLeft } from 'lucide-react';
import { generatePermitPDF } from '@/lib/pdfGenerator';

export default function PermitVerification() {
  const navigate = useNavigate();
  const { permits } = usePermits();
  const [permitNumber, setPermitNumber] = useState('');
  const [error, setError] = useState('');
  const [verifiedPermit, setVerifiedPermit] = useState<any>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleVerify = () => {
    setError('');
    setVerifiedPermit(null);
    setIsVerifying(true);

    if (!permitNumber.trim()) {
      setError('Please enter a permit number');
      setIsVerifying(false);
      return;
    }

    // Find permit by permit number
    const permit = permits.find(p => p.permitNumber.toLowerCase() === permitNumber.trim().toLowerCase());

    if (!permit) {
      setError('Permit not found. Please check the permit number and try again.');
      setIsVerifying(false);
      return;
    }

    // Check if permit is issued (only issued permits can be verified)
    if (permit.status !== 'issued' && permit.status !== 'active' && permit.status !== 'closed') {
      setError('This permit has not been issued yet or is not in a verifiable state.');
      setIsVerifying(false);
      return;
    }

    setVerifiedPermit(permit);
    setIsVerifying(false);
  };

  const handleDownloadPDF = async () => {
    if (!verifiedPermit) return;
    try {
      await generatePermitPDF(verifiedPermit);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')} 
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Login
        </Button>

        <Card className="shadow-xl">
          <CardHeader className="text-center bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
            <div className="flex justify-center mb-4">
              <ShieldCheck className="h-16 w-16" />
            </div>
            <CardTitle className="text-3xl">Permit Verification</CardTitle>
            <CardDescription className="text-blue-100">
              Enter the permit number to verify and view permit details
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            {!verifiedPermit ? (
              <div className="space-y-6">
                <div>
                  <Label htmlFor="permitNumber" className="text-lg">Permit Number</Label>
                  <Input
                    id="permitNumber"
                    value={permitNumber}
                    onChange={(e) => setPermitNumber(e.target.value)}
                    placeholder="e.g., PTW-2025-01-001"
                    className="mt-2 text-lg h-12"
                    onKeyPress={(e) => e.key === 'Enter' && handleVerify()}
                  />
                  <p className="text-sm text-gray-500 mt-2">
                    Enter the permit number exactly as shown on the permit document
                  </p>
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button 
                  onClick={handleVerify} 
                  className="w-full h-12 text-lg bg-blue-600 hover:bg-blue-700"
                  disabled={isVerifying}
                >
                  {isVerifying ? 'Verifying...' : 'Verify Permit'}
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                <Alert className="bg-green-50 border-green-200">
                  <ShieldCheck className="h-5 w-5 text-green-600" />
                  <AlertDescription className="text-green-800 font-semibold">
                    ✓ Permit Verified Successfully
                  </AlertDescription>
                </Alert>

                <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Permit Number</p>
                      <p className="font-semibold text-lg">{verifiedPermit.permitNumber}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status</p>
                      <p className="font-semibold text-lg capitalize">{verifiedPermit.status.replace(/_/g, ' ')}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Permit Type</p>
                      <p className="font-semibold">{verifiedPermit.type}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Department</p>
                      <p className="font-semibold">{verifiedPermit.department}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-sm text-gray-600">Title</p>
                      <p className="font-semibold">{verifiedPermit.title}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-sm text-gray-600">Location</p>
                      <p className="font-semibold">{verifiedPermit.location}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Issued By</p>
                      <p className="font-semibold">{verifiedPermit.issuerName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Issued Date</p>
                      <p className="font-semibold">
                        {verifiedPermit.lastIssuedDate 
                          ? new Date(verifiedPermit.lastIssuedDate).toLocaleDateString()
                          : 'N/A'}
                      </p>
                    </div>
                    {verifiedPermit.renewalCount > 0 && (
                      <div className="col-span-2">
                        <p className="text-sm text-gray-600">Renewals</p>
                        <p className="font-semibold">{verifiedPermit.renewalCount}/7</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button 
                    onClick={handleDownloadPDF} 
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    Download PDF
                  </Button>
                  <Button 
                    onClick={() => {
                      setVerifiedPermit(null);
                      setPermitNumber('');
                      setError('');
                    }}
                    variant="outline"
                    className="flex-1"
                  >
                    Verify Another
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>This verification system ensures the authenticity of issued permits.</p>
          <p className="mt-1">For support, contact your system administrator.</p>
        </div>
      </div>
    </div>
  );
}
