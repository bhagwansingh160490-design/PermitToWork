-- Insert demo permits with various statuses

-- Get user IDs for reference
DO $$
DECLARE
  receiver_id UUID;
  applicant_id UUID;
  issuer_id UUID;
BEGIN
  -- Get user IDs
  SELECT id INTO receiver_id FROM users WHERE email = 'receiver@ptw.com';
  SELECT id INTO applicant_id FROM users WHERE email = 'applicant@ptw.com';
  SELECT id INTO issuer_id FROM users WHERE email = 'issuer@ptw.com';

  -- Demo Permit 1: Issued Hot Work Permit (Week 51 of 2024)
  INSERT INTO permits (
    permit_number, type, status, title, description, location, department,
    work_start_date, work_start_time, expected_completion_date, expected_completion_time,
    hazards, precautions, required_ppe, created_by, receiver_name, receiver_department,
    applicant_name, issuer_name, last_issued_date, created_at
  ) VALUES (
    'PTW-2024-51-001', 'Hot Work', 'issued', 'Welding Work on Pipeline',
    'Welding repairs on main pipeline section B', 'Plant Area B - Pipeline Section',
    'Mechanical', CURRENT_DATE, '08:00:00', CURRENT_DATE, '17:00:00',
    ARRAY['Fire hazard', 'Hot surfaces', 'Fumes'], 
    'Fire extinguisher on site, Hot work blankets, Ventilation system active',
    ARRAY['Welding helmet', 'Fire-resistant gloves', 'Safety boots'],
    receiver_id, 'Receiver User', 'Civil', 'Applicant User', 'Issuer User',
    NOW(), NOW() - INTERVAL '2 hours'
  );

  -- Demo Permit 2: Pending Issue (Confined Space)
  INSERT INTO permits (
    permit_number, type, status, title, description, location, department,
    work_start_date, work_start_time, expected_completion_date, expected_completion_time,
    hazards, precautions, required_ppe, created_by, receiver_name, receiver_department,
    applicant_name, created_at
  ) VALUES (
    'DRAFT-' || gen_random_uuid()::text, 'Confined Space', 'pending_issue',
    'Tank Inspection and Cleaning', 'Internal inspection of storage tank T-101',
    'Storage Area - Tank T-101', 'Civil', CURRENT_DATE + INTERVAL '1 day', '09:00:00',
    CURRENT_DATE + INTERVAL '1 day', '15:00:00',
    ARRAY['Oxygen deficiency', 'Toxic atmosphere', 'Engulfment'],
    'Gas testing before entry, Continuous air monitoring, Rescue equipment ready',
    ARRAY['SCBA', 'Full body harness', 'Gas detector'],
    receiver_id, 'Receiver User', 'Civil', 'Applicant User',
    NOW() - INTERVAL '1 hour'
  );

  -- Demo Permit 3: Pending Applicant Review (Electrical Work)
  INSERT INTO permits (
    permit_number, type, status, title, description, location, department,
    work_start_date, work_start_time, expected_completion_date, expected_completion_time,
    hazards, precautions, required_ppe, created_by, receiver_name, receiver_department,
    created_at
  ) VALUES (
    'DRAFT-' || gen_random_uuid()::text, 'Electrical Work', 'pending_applicant_review',
    'Motor Control Panel Maintenance', 'Preventive maintenance on MCC-3',
    'Electrical Room 2', 'Electrical', CURRENT_DATE + INTERVAL '2 days', '10:00:00',
    CURRENT_DATE + INTERVAL '2 days', '16:00:00',
    ARRAY['Electric shock', 'Arc flash', 'Burns'],
    'LOTO procedures applied, Voltage testing, Insulated tools only',
    ARRAY['Arc flash suit', 'Insulated gloves', 'Face shield'],
    receiver_id, 'Receiver User', 'Civil', NOW() - INTERVAL '30 minutes'
  );

  -- Demo Permit 4: Pending Renewal (Working at Height) - Week 50
  INSERT INTO permits (
    permit_number, type, status, title, description, location, department,
    work_start_date, work_start_time, expected_completion_date, expected_completion_time,
    hazards, precautions, required_ppe, created_by, receiver_name, receiver_department,
    applicant_name, issuer_name, last_issued_date, renewal_count, created_at
  ) VALUES (
    'PTW-2024-50-002', 'Working at Height', 'pending_renewal',
    'Roof Maintenance Work', 'Inspection and repair of roof panels',
    'Building A - Roof Level', 'Civil', CURRENT_DATE, '07:00:00',
    CURRENT_DATE, '18:00:00',
    ARRAY['Fall from height', 'Slips and trips', 'Weather conditions'],
    'Fall protection system, Safety nets installed, Weather monitoring',
    ARRAY['Full body harness', 'Hard hat', 'Non-slip boots'],
    receiver_id, 'Receiver User', 'Civil', 'Applicant User', 'Issuer User',
    NOW() - INTERVAL '25 hours', 1, NOW() - INTERVAL '3 days'
  );

  -- Demo Permit 5: Rejected (Cold Work)
  INSERT INTO permits (
    permit_number, type, status, title, description, location, department,
    work_start_date, work_start_time, expected_completion_date, expected_completion_time,
    hazards, precautions, required_ppe, created_by, receiver_name, receiver_department,
    applicant_name, rejection_reason, created_at
  ) VALUES (
    'DRAFT-' || gen_random_uuid()::text, 'Cold Work', 'rejected',
    'Painting Work in Workshop', 'Repainting workshop walls and equipment',
    'Workshop Area C', 'Mechanical', CURRENT_DATE + INTERVAL '3 days', '08:00:00',
    CURRENT_DATE + INTERVAL '5 days', '17:00:00',
    ARRAY['Chemical exposure', 'Slips from wet surfaces'],
    'Ventilation, Wet floor signs, Chemical handling procedures',
    ARRAY['Respirator', 'Chemical gloves', 'Safety goggles'],
    receiver_id, 'Receiver User', 'Civil', 'Applicant User',
    'Insufficient ventilation plan. Please provide detailed ventilation setup and air quality monitoring procedures.',
    NOW() - INTERVAL '4 hours'
  );

  -- Demo Permit 6: Closed (Excavation) - Week 48
  INSERT INTO permits (
    permit_number, type, status, title, description, location, department,
    work_start_date, work_start_time, expected_completion_date, expected_completion_time,
    hazards, precautions, required_ppe, created_by, receiver_name, receiver_department,
    applicant_name, issuer_name, last_issued_date, closed_at, closed_by, created_at
  ) VALUES (
    'PTW-2024-48-003', 'Excavation', 'closed',
    'Underground Cable Installation', 'Installing new power cables underground',
    'Parking Lot - North Section', 'Electrical', CURRENT_DATE - INTERVAL '5 days', '07:00:00',
    CURRENT_DATE - INTERVAL '5 days', '18:00:00',
    ARRAY['Cave-in', 'Underground utilities', 'Heavy equipment'],
    'Shoring system, Utility locating completed, Barricades installed',
    ARRAY['Hard hat', 'High-vis vest', 'Steel-toe boots'],
    receiver_id, 'Receiver User', 'Civil', 'Applicant User', 'Issuer User',
    NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days', 'Issuer User',
    NOW() - INTERVAL '6 days'
  );

END $$;

-- Add approval history for the demo permits
INSERT INTO approval_history (permit_id, action, by_user, role, timestamp, comments)
SELECT 
  p.id,
  CASE 
    WHEN p.status = 'issued' THEN 'issued'
    WHEN p.status = 'pending_issue' THEN 'submitted_for_issue'
    WHEN p.status = 'pending_applicant_review' THEN 'submitted_for_review'
    WHEN p.status = 'pending_renewal' THEN 'renewal_requested'
    WHEN p.status = 'rejected' THEN 'rejected'
    WHEN p.status = 'closed' THEN 'closed'
  END,
  CASE 
    WHEN p.status IN ('issued', 'closed') THEN p.issuer_name
    WHEN p.status IN ('pending_issue', 'pending_renewal') THEN p.applicant_name
    WHEN p.status = 'pending_applicant_review' THEN p.receiver_name
    WHEN p.status = 'rejected' THEN p.applicant_name
  END,
  CASE 
    WHEN p.status IN ('issued', 'closed') THEN 'issuer'
    WHEN p.status IN ('pending_issue', 'pending_renewal') THEN 'applicant'
    WHEN p.status = 'pending_applicant_review' THEN 'receiver'
    WHEN p.status = 'rejected' THEN 'applicant'
  END,
  p.created_at,
  CASE 
    WHEN p.status = 'rejected' THEN p.rejection_reason
    WHEN p.status = 'closed' THEN 'Work completed successfully'
    ELSE NULL
  END
FROM permits p
WHERE p.permit_number LIKE 'PTW-%' OR p.permit_number LIKE 'DRAFT-%';