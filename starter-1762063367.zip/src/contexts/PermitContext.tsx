import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Permit, PermitStatus, RenewalRecord } from '@/types/permit';
import { supabase } from '@/lib/supabaseClient';

interface PermitContextType {
  permits: Permit[];
  addPermit: (permit: Permit) => Promise<void>;
  updatePermit: (id: string, updates: Partial<Permit>) => Promise<void>;
  deletePermit: (id: string) => Promise<void>;
  generateFinalPermitNumber: () => Promise<string>;
  loading: boolean;
  error: string | null;
}

const PermitContext = createContext<PermitContextType | undefined>(undefined);

// Helper to get ISO week number
const getWeekNumber = (date: Date): number => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
};

// Helper function to check if permit is older than 10 days
const isOlderThan10Days = (createdAt: string): boolean => {
  const createdDate = new Date(createdAt);
  const currentDate = new Date();
  const daysDiff = Math.floor((currentDate.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
  return daysDiff > 10;
};

// Helper function to check if it's past midnight (12 AM) since last issued/renewal
const needsRenewal = (lastIssuedDate: string): boolean => {
  const lastIssued = new Date(lastIssuedDate);
  const now = new Date();
  
  // Set both to midnight for comparison
  const lastIssuedMidnight = new Date(lastIssued);
  lastIssuedMidnight.setHours(0, 0, 0, 0);
  
  const todayMidnight = new Date(now);
  todayMidnight.setHours(0, 0, 0, 0);
  
  return todayMidnight > lastIssuedMidnight;
};

export function PermitProvider({ children }: { children: ReactNode }) {
  const [permits, setPermits] = useState<Permit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch permits from Supabase
  const fetchPermits = async () => {
    try {
      setLoading(true);
      
      // Check if Supabase is configured
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseKey) {
        console.warn('Supabase not configured. Using empty permits array.');
        setPermits([]);
        setError(null);
        setLoading(false);
        return;
      }

      // Fetch permits with approval history
      const { data: permitsData, error: fetchError } = await supabase
        .from('permits')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) {
        if (fetchError.code === 'PGRST205' || fetchError.message?.includes('schema cache')) {
          console.warn('Permits table not found. Database may need migration.');
          setPermits([]);
          setError(null);
        } else {
          throw fetchError;
        }
      } else {
        // Fetch approval history for all permits
        const permitIds = (permitsData || []).map(p => p.id);
        const { data: approvalData } = await supabase
          .from('approval_history')
          .select('*')
          .in('permit_id', permitIds)
          .order('timestamp', { ascending: true });

        // Map database records to frontend Permit type
        const mappedPermits: Permit[] = (permitsData || []).map(dbPermit => {
          const permitApprovals = (approvalData || [])
            .filter(ah => ah.permit_id === dbPermit.id)
            .map(ah => ({
              action: ah.action,
              by: ah.by_user,
              role: ah.role,
              timestamp: ah.timestamp,
              comments: ah.comments,
              signature: ah.signature,
              renewalNumber: ah.renewal_number
            }));

          return {
            id: dbPermit.id,
            permitNumber: dbPermit.permit_number,
            type: dbPermit.type,
            status: dbPermit.status,
            title: dbPermit.title,
            description: dbPermit.description,
            location: dbPermit.location,
            department: dbPermit.department,
            workStartDate: dbPermit.work_start_date,
            workStartTime: dbPermit.work_start_time,
            expectedCompletionDate: dbPermit.expected_completion_date,
            expectedCompletionTime: dbPermit.expected_completion_time,
            expiryDate: dbPermit.expiry_date,
            hazards: dbPermit.hazards || [],
            precautions: dbPermit.precautions || '',
            requiredPPE: dbPermit.required_ppe || [],
            createdBy: dbPermit.created_by,
            createdAt: dbPermit.created_at,
            updatedAt: dbPermit.updated_at,
            receiverName: dbPermit.receiver_name,
            receiverDepartment: dbPermit.receiver_department,
            applicantName: dbPermit.applicant_name,
            issuerName: dbPermit.issuer_name,
            approvalHistory: permitApprovals,
            rejectionReason: dbPermit.rejection_reason,
            renewalCount: dbPermit.renewal_count || 0,
            lastRenewalDate: dbPermit.last_renewal_date,
            lastIssuedDate: dbPermit.last_issued_date,
            closedAt: dbPermit.closed_at,
            closedBy: dbPermit.closed_by
          };
        });

        setPermits(mappedPermits);
        setError(null);
      }
    } catch (err: any) {
      console.error('Error fetching permits:', err);
      setError(err.message);
      setPermits([]);
    } finally {
      setLoading(false);
    }
  };

  // Load permits on mount
  useEffect(() => {
    fetchPermits();
  }, []);

  // Generate final permit number in PTW-YYYY-WW-CCC format using database function
  const generateFinalPermitNumber = async (): Promise<string> => {
    try {
      // Call the database function to generate permit number
      const { data, error } = await supabase
        .rpc('generate_permit_number');

      if (error) {
        console.error('Error calling generate_permit_number:', error);
        throw error;
      }

      if (!data) {
        throw new Error('No permit number returned from database');
      }

      return data;
    } catch (err) {
      console.error('Error generating permit number:', err);
      // Fallback to client-side generation
      const now = new Date();
      const year = now.getFullYear();
      const week = getWeekNumber(now);
      return `PTW-${year}-${String(week).padStart(2, '0')}-001`;
    }
  };

  // Auto-close permits older than 10 days and check for daily renewals
  useEffect(() => {
    const checkPermits = async () => {
      try {
        const permitsToUpdate: Array<{ id: string; updates: any }> = [];

        permits.forEach(permit => {
          // Auto-close if older than 10 days
          if ((permit.status === 'issued' || permit.status === 'active' || permit.status === 'pending_renewal') && isOlderThan10Days(permit.created_at)) {
            permitsToUpdate.push({
              id: permit.id,
              updates: {
                status: 'closed',
                closed_at: new Date().toISOString(),
                closed_by: permit.issuer_name || 'System Auto-Close'
              }
            });
          }

          // Check if issued permit needs daily renewal (after midnight)
          if (permit.status === 'issued' && permit.last_issued_date && needsRenewal(permit.last_issued_date)) {
            const renewalCount = permit.renewal_count || 0;
            
            // If already renewed 7 times, close the permit
            if (renewalCount >= 7) {
              permitsToUpdate.push({
                id: permit.id,
                updates: {
                  status: 'closed',
                  closed_at: new Date().toISOString(),
                  closed_by: permit.issuer_name || 'System'
                }
              });
            } else {
              // Move to pending_renewal status
              permitsToUpdate.push({
                id: permit.id,
                updates: {
                  status: 'pending_renewal'
                }
              });
            }
          }
        });

        // Update all permits that need changes
        for (const { id, updates } of permitsToUpdate) {
          await supabase
            .from('permits')
            .update(updates)
            .eq('id', id);
        }

        // Refresh permits if any were updated
        if (permitsToUpdate.length > 0) {
          await fetchPermits();
        }
      } catch (err) {
        console.error('Error checking permits:', err);
      }
    };

    // Check immediately on mount
    if (permits.length > 0) {
      checkPermits();
    }

    // Check every hour
    const interval = setInterval(checkPermits, 60 * 60 * 1000);

    return () => clearInterval(interval);
  }, [permits]);

  const addPermit = async (permit: Permit) => {
    try {
      // Insert permit without ID (let database generate it)
      const { data, error } = await supabase
        .from('permits')
        .insert([{
          permit_number: permit.permitNumber,
          type: permit.type,
          status: permit.status,
          title: permit.title,
          description: permit.description,
          location: permit.location,
          department: permit.department,
          work_start_date: permit.workStartDate,
          work_start_time: permit.workStartTime,
          expected_completion_date: permit.expectedCompletionDate,
          expected_completion_time: permit.expectedCompletionTime,
          hazards: permit.hazards,
          precautions: permit.precautions,
          required_ppe: permit.requiredPPE,
          created_by: permit.createdBy || null,
          receiver_name: permit.receiverName,
          receiver_department: permit.receiverDepartment,
          applicant_name: permit.applicantName || null,
          issuer_name: permit.issuerName || null,
          renewal_count: permit.renewalCount || 0
        }])
        .select()
        .single();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      if (!data) {
        throw new Error('No data returned from insert');
      }

      // Add approval history
      if (permit.approvalHistory && permit.approvalHistory.length > 0) {
        const historyInserts = permit.approvalHistory.map(ah => ({
          permit_id: data.id,
          action: ah.action,
          by_user: ah.by,
          role: ah.role,
          timestamp: ah.timestamp,
          comments: ah.comments || null,
          signature: ah.signature || null,
          renewal_number: ah.renewalNumber || null
        }));

        const { error: historyError } = await supabase
          .from('approval_history')
          .insert(historyInserts);

        if (historyError) {
          console.error('Error adding approval history:', historyError);
        }
      }

      await fetchPermits();
    } catch (err: any) {
      console.error('Error adding permit:', err);
      setError(err.message);
      throw err; // Re-throw so the form can handle it
    }
  };

  const updatePermit = async (id: string, updates: Partial<Permit>) => {
    try {
      // Map frontend field names to database column names
      const dbUpdates: any = {};
      
      if (updates.permitNumber) dbUpdates.permit_number = updates.permitNumber;
      if (updates.type) dbUpdates.type = updates.type;
      if (updates.status) dbUpdates.status = updates.status;
      if (updates.title) dbUpdates.title = updates.title;
      if (updates.description) dbUpdates.description = updates.description;
      if (updates.location) dbUpdates.location = updates.location;
      if (updates.department) dbUpdates.department = updates.department;
      if (updates.workStartDate) dbUpdates.work_start_date = updates.workStartDate;
      if (updates.workStartTime) dbUpdates.work_start_time = updates.workStartTime;
      if (updates.expectedCompletionDate) dbUpdates.expected_completion_date = updates.expectedCompletionDate;
      if (updates.expectedCompletionTime) dbUpdates.expected_completion_time = updates.expectedCompletionTime;
      if (updates.hazards) dbUpdates.hazards = updates.hazards;
      if (updates.precautions) dbUpdates.precautions = updates.precautions;
      if (updates.requiredPPE) dbUpdates.required_ppe = updates.requiredPPE;
      if (updates.receiverName) dbUpdates.receiver_name = updates.receiverName;
      if (updates.receiverDepartment) dbUpdates.receiver_department = updates.receiverDepartment;
      if (updates.applicantName) dbUpdates.applicant_name = updates.applicantName;
      if (updates.issuerName) dbUpdates.issuer_name = updates.issuerName;
      if (updates.rejectionReason) dbUpdates.rejection_reason = updates.rejectionReason;
      if (updates.renewalCount !== undefined) dbUpdates.renewal_count = updates.renewalCount;
      if (updates.lastRenewalDate) dbUpdates.last_renewal_date = updates.lastRenewalDate;
      if (updates.lastIssuedDate) dbUpdates.last_issued_date = updates.lastIssuedDate;
      if (updates.closedAt) dbUpdates.closed_at = updates.closedAt;
      if (updates.closedBy) dbUpdates.closed_by = updates.closedBy;
      
      // Always update the updated_at timestamp
      dbUpdates.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('permits')
        .update(dbUpdates)
        .eq('id', id);

      if (error) {
        console.error('Database update error:', error);
        throw error;
      }

      // Add approval history if provided
      if (updates.approvalHistory && updates.approvalHistory.length > 0) {
        const newHistory = updates.approvalHistory[updates.approvalHistory.length - 1];
        const { error: historyError } = await supabase
          .from('approval_history')
          .insert({
            permit_id: id,
            action: newHistory.action,
            by_user: newHistory.by,
            role: newHistory.role,
            timestamp: newHistory.timestamp,
            comments: newHistory.comments || null,
            signature: newHistory.signature || null,
            renewal_number: newHistory.renewalNumber || null
          });
        
        if (historyError) {
          console.error('Error adding approval history:', historyError);
          throw historyError;
        }
      }

      await fetchPermits();
    } catch (err: any) {
      console.error('Error updating permit:', err);
      setError(err.message);
      throw err; // Re-throw so calling function can handle it
    }
  };

  const deletePermit = async (id: string) => {
    try {
      const { error } = await supabase
        .from('permits')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await fetchPermits();
    } catch (err: any) {
      console.error('Error deleting permit:', err);
      setError(err.message);
    }
  };

  return (
    <PermitContext.Provider value={{ permits, addPermit, updatePermit, deletePermit, generateFinalPermitNumber, loading, error }}>
      {children}
    </PermitContext.Provider>
  );
}

export function usePermits() {
  const context = useContext(PermitContext);
  if (context === undefined) {
    throw new Error('usePermits must be used within a PermitProvider');
  }
  return context;
}