import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertCircle } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    try {
      // Add slight delay to prevent timing attacks
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const result = await login(email, password);
      
      if (result.success) {
        navigate('/dashboard');
      } else {
        setError(result.message || 'Login failed');
        // Clear password on failed attempt
        setPassword('');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      setPassword('');
    } finally {
      setIsLoading(false);
    }
  };

  const demoAccounts = [
    { role: 'Permit Receiver', email: 'receiver@ptw.com', password: 'admin123', dept: 'Civil Dept' },
    { role: 'Permit Applicant', email: 'applicant@ptw.com', password: 'admin123', dept: 'Mechanical Dept' },
    { role: 'Permit Issuer', email: 'issuer@ptw.com', password: 'admin123', dept: 'Electrical Dept' },
    { role: 'Admin', email: 'admin@ptw.com', password: 'admin123', dept: 'Administration' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid md:grid-cols-2 gap-6">
        <Card className="shadow-xl">
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-8 w-8 text-blue-600" />
              <CardTitle className="text-2xl font-bold">Permit-to-Work System</CardTitle>
            </div>
            <CardDescription>Sign in to access the electronic permit management system</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  required
                  autoComplete="email"
                  maxLength={100}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                  required
                  autoComplete="current-password"
                  maxLength={100}
                />
              </div>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Signing In...' : 'Sign In'}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="shadow-xl bg-blue-50">
          <CardHeader>
            <CardTitle className="text-lg">Demo Accounts</CardTitle>
            <CardDescription>Use these credentials to test different roles</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {demoAccounts.map((account, idx) => (
              <div key={idx} className="bg-white p-3 rounded-lg border border-blue-200">
                <div className="font-semibold text-sm text-blue-900">{account.role}</div>
                {account.dept && <div className="text-xs text-gray-600">{account.dept}</div>}
                <div className="text-xs text-gray-700 mt-1">
                  <div>Email: <span className="font-mono">{account.email}</span></div>
                  <div>Password: <span className="font-mono">{account.password}</span></div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}