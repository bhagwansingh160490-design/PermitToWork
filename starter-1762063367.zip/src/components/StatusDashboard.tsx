import { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePermits } from '@/contexts/PermitContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, LogOut, Eye, Search, Filter } from 'lucide-react';
import { PermitStatus, Department } from '@/types/permit';

const STATUS_CONFIG: Record<PermitStatus, { label: string; color: string }> = {
  draft: { label: 'Draft', color: 'bg-gray-500' },
  pending_applicant_review: { label: 'Pending Applicant Review', color: 'bg-yellow-500' },
  pending_issue: { label: 'Pending Issue', color: 'bg-orange-500' },
  issued: { label: 'Issued', color: 'bg-green-500' },
  active: { label: 'Active', color: 'bg-blue-500' },
  returned_for_modification: { label: 'Returned', color: 'bg-purple-500' },
  rejected: { label: 'Rejected', color: 'bg-red-600' },
  expired: { label: 'Expired', color: 'bg-red-700' },
  closed: { label: 'Closed', color: 'bg-gray-600' },
  pending_renewal: { label: 'Pending Renewal', color: 'bg-amber-500' }
};

export default function StatusDashboard() {
  const { user, logout } = useAuth();
  const { permits } = usePermits();
  const navigate = useNavigate();

  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState<string>('all');
  const [filterReceiver, setFilterReceiver] = useState<string>('all');
  const [filterApplicant, setFilterApplicant] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Get unique values for filters
  const uniqueReceivers = useMemo(() => {
    const receivers = new Set(permits.map(p => p.receiverName).filter(Boolean));
    return Array.from(receivers).sort();
  }, [permits]);

  const uniqueApplicants = useMemo(() => {
    const applicants = new Set(permits.map(p => p.applicantName).filter(Boolean));
    return Array.from(applicants).sort();
  }, [permits]);

  // Filter permits
  const filteredPermits = useMemo(() => {
    return permits.filter(permit => {
      // Search filter - handle null/undefined values
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = !searchTerm || 
        (permit.permitNumber || '').toLowerCase().includes(searchLower) ||
        (permit.title || '').toLowerCase().includes(searchLower) ||
        (permit.location || '').toLowerCase().includes(searchLower) ||
        (permit.receiverName || '').toLowerCase().includes(searchLower) ||
        (permit.applicantName && permit.applicantName.toLowerCase().includes(searchLower));

      // Department filter
      const matchesDepartment = filterDepartment === 'all' || permit.department === filterDepartment;

      // Receiver filter - handle null/undefined
      const matchesReceiver = filterReceiver === 'all' || (permit.receiverName && permit.receiverName === filterReceiver);

      // Applicant filter - handle null/undefined
      const matchesApplicant = filterApplicant === 'all' || (permit.applicantName && permit.applicantName === filterApplicant);

      // Status filter
      const matchesStatus = filterStatus === 'all' || permit.status === filterStatus;

      return matchesSearch && matchesDepartment && matchesReceiver && matchesApplicant && matchesStatus;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [permits, searchTerm, filterDepartment, filterReceiver, filterApplicant, filterStatus]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterDepartment('all');
    setFilterReceiver('all');
    setFilterApplicant('all');
    setFilterStatus('all');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-full px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Real-Time Permit Status Dashboard</h1>
                <p className="text-sm text-gray-600">
                  {user?.name} • {user?.role.charAt(0).toUpperCase() + user?.role.slice(1)}
                  {user?.department && ` • ${user.department} Department`}
                </p>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-full px-6 py-6">
        {/* Filters Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Search & Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="lg:col-span-2">
                <label className="text-sm font-medium mb-2 block">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by permit number, title, location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Department Filter */}
              <div>
                <label className="text-sm font-medium mb-2 block">Department</label>
                <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Departments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    <SelectItem value="Civil">Civil</SelectItem>
                    <SelectItem value="Mechanical">Mechanical</SelectItem>
                    <SelectItem value="Electrical">Electrical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Receiver Filter */}
              <div>
                <label className="text-sm font-medium mb-2 block">Receiver</label>
                <Select value={filterReceiver} onValueChange={setFilterReceiver}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Receivers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Receivers</SelectItem>
                    {uniqueReceivers.map(receiver => (
                      <SelectItem key={receiver} value={receiver}>{receiver}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Applicant Filter */}
              <div>
                <label className="text-sm font-medium mb-2 block">Applicant</label>
                <Select value={filterApplicant} onValueChange={setFilterApplicant}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Applicants" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Applicants</SelectItem>
                    {uniqueApplicants.map(applicant => (
                      <SelectItem key={applicant} value={applicant}>{applicant}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Status Filter - Full Width */}
              <div className="lg:col-span-3">
                <label className="text-sm font-medium mb-2 block">Permit Status</label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {Object.entries(STATUS_CONFIG).map(([status, config]) => (
                      <SelectItem key={status} value={status}>{config.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Clear Filters Button */}
              <div className="lg:col-span-2 flex items-end">
                <Button variant="outline" onClick={clearFilters} className="w-full">
                  Clear All Filters
                </Button>
              </div>
            </div>

            {/* Results Count */}
            <div className="mt-4 text-sm text-gray-600">
              Showing <span className="font-semibold">{filteredPermits.length}</span> of <span className="font-semibold">{permits.length}</span> permits
            </div>
          </CardContent>
        </Card>

        {/* Permits Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="font-semibold">Permit Number</TableHead>
                    <TableHead className="font-semibold">Department</TableHead>
                    <TableHead className="font-semibold">Location</TableHead>
                    <TableHead className="font-semibold">Receiver</TableHead>
                    <TableHead className="font-semibold">Applicant</TableHead>
                    <TableHead className="font-semibold">Issuer</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold text-center">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPermits.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-12 text-gray-500">
                        No permits found matching your filters
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPermits.map((permit) => (
                      <TableRow key={permit.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium">
                          <div>
                            <div className="font-semibold text-blue-600">{permit.permitNumber || '-'}</div>
                            <div className="text-xs text-gray-500">{permit.title || '-'}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {permit.department ? (
                            <Badge variant="outline">{permit.department}</Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell className="max-w-[200px]">
                          {permit.location ? (
                            <div className="truncate" title={permit.location}>
                              {permit.location}
                            </div>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {permit.receiverName || <span className="text-gray-400">-</span>}
                        </TableCell>
                        <TableCell>
                          {permit.applicantName || <span className="text-gray-400">-</span>}
                        </TableCell>
                        <TableCell>
                          {permit.issuerName || <span className="text-gray-400">-</span>}
                        </TableCell>
                        <TableCell>
                          {permit.status && STATUS_CONFIG[permit.status] ? (
                            <Badge className={`${STATUS_CONFIG[permit.status].color} text-white`}>
                              {STATUS_CONFIG[permit.status].label}
                            </Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/permit/${permit.id}`)}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}