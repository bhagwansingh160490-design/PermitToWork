export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      approval_history: {
        Row: {
          action: string
          by_user: string
          comments: string | null
          created_at: string | null
          id: string
          permit_id: string | null
          renewal_number: number | null
          role: string
          signature: string | null
          timestamp: string | null
        }
        Insert: {
          action: string
          by_user: string
          comments?: string | null
          created_at?: string | null
          id?: string
          permit_id?: string | null
          renewal_number?: number | null
          role: string
          signature?: string | null
          timestamp?: string | null
        }
        Update: {
          action?: string
          by_user?: string
          comments?: string | null
          created_at?: string | null
          id?: string
          permit_id?: string | null
          renewal_number?: number | null
          role?: string
          signature?: string | null
          timestamp?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "approval_history_permit_id_fkey"
            columns: ["permit_id"]
            isOneToOne: false
            referencedRelation: "permits"
            referencedColumns: ["id"]
          },
        ]
      }
      permit_documents: {
        Row: {
          file_name: string
          file_size: number | null
          file_type: string | null
          file_url: string
          id: string
          permit_id: string | null
          uploaded_at: string | null
          uploaded_by: string | null
        }
        Insert: {
          file_name: string
          file_size?: number | null
          file_type?: string | null
          file_url: string
          id?: string
          permit_id?: string | null
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Update: {
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          file_url?: string
          id?: string
          permit_id?: string | null
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "permit_documents_permit_id_fkey"
            columns: ["permit_id"]
            isOneToOne: false
            referencedRelation: "permits"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "permit_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      permits: {
        Row: {
          applicant_name: string | null
          closed_at: string | null
          closed_by: string | null
          created_at: string | null
          created_by: string | null
          department: string
          description: string
          expected_completion_date: string
          expected_completion_time: string
          expiry_date: string | null
          hazards: string[] | null
          id: string
          issuer_name: string | null
          last_issued_date: string | null
          last_renewal_date: string | null
          location: string
          permit_number: string
          precautions: string
          receiver_department: string
          receiver_name: string
          rejection_reason: string | null
          renewal_count: number | null
          required_ppe: string[] | null
          status: string
          title: string
          type: string
          updated_at: string | null
          work_start_date: string
          work_start_time: string
        }
        Insert: {
          applicant_name?: string | null
          closed_at?: string | null
          closed_by?: string | null
          created_at?: string | null
          created_by?: string | null
          department: string
          description: string
          expected_completion_date: string
          expected_completion_time: string
          expiry_date?: string | null
          hazards?: string[] | null
          id?: string
          issuer_name?: string | null
          last_issued_date?: string | null
          last_renewal_date?: string | null
          location: string
          permit_number: string
          precautions: string
          receiver_department: string
          receiver_name: string
          rejection_reason?: string | null
          renewal_count?: number | null
          required_ppe?: string[] | null
          status: string
          title: string
          type: string
          updated_at?: string | null
          work_start_date: string
          work_start_time: string
        }
        Update: {
          applicant_name?: string | null
          closed_at?: string | null
          closed_by?: string | null
          created_at?: string | null
          created_by?: string | null
          department?: string
          description?: string
          expected_completion_date?: string
          expected_completion_time?: string
          expiry_date?: string | null
          hazards?: string[] | null
          id?: string
          issuer_name?: string | null
          last_issued_date?: string | null
          last_renewal_date?: string | null
          location?: string
          permit_number?: string
          precautions?: string
          receiver_department?: string
          receiver_name?: string
          rejection_reason?: string | null
          renewal_count?: number | null
          required_ppe?: string[] | null
          status?: string
          title?: string
          type?: string
          updated_at?: string | null
          work_start_date?: string
          work_start_time?: string
        }
        Relationships: [
          {
            foreignKeyName: "permits_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      renewal_history: {
        Row: {
          applicant_name: string | null
          approved_by: string | null
          approved_date: string | null
          created_at: string | null
          id: string
          issued_by: string | null
          issued_date: string | null
          issuer_name: string | null
          permit_id: string | null
          receiver_name: string
          renewal_number: number
          requested_by: string
          requested_date: string
          signature: string | null
        }
        Insert: {
          applicant_name?: string | null
          approved_by?: string | null
          approved_date?: string | null
          created_at?: string | null
          id?: string
          issued_by?: string | null
          issued_date?: string | null
          issuer_name?: string | null
          permit_id?: string | null
          receiver_name: string
          renewal_number: number
          requested_by: string
          requested_date: string
          signature?: string | null
        }
        Update: {
          applicant_name?: string | null
          approved_by?: string | null
          approved_date?: string | null
          created_at?: string | null
          id?: string
          issued_by?: string | null
          issued_date?: string | null
          issuer_name?: string | null
          permit_id?: string | null
          receiver_name?: string
          renewal_number?: number
          requested_by?: string
          requested_date?: string
          signature?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "renewal_history_permit_id_fkey"
            columns: ["permit_id"]
            isOneToOne: false
            referencedRelation: "permits"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          created_at: string | null
          department: string | null
          email: string
          id: string
          name: string
          password_hash: string
          role: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          department?: string | null
          email: string
          id?: string
          name: string
          password_hash: string
          role: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          department?: string | null
          email?: string
          id?: string
          name?: string
          password_hash?: string
          role?: string
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      auto_close_old_permits: { Args: never; Returns: undefined }
      check_daily_renewals: { Args: never; Returns: undefined }
      generate_permit_number: { Args: never; Returns: string }
      get_week_number: { Args: { input_date: string }; Returns: number }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
