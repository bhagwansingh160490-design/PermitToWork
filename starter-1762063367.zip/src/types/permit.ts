export type UserRole = 'receiver' | 'applicant' | 'issuer' | 'admin';
export type Department = 'Civil' | 'Mechanical' | 'Electrical';
export type PermitType = 'Cold Work' | 'Hot Work' | 'Confined Space' | 'Working at Height' | 'Excavation' | 'Electrical Work' | 'Lifting Operations';
export type PermitStatus = 'draft' | 'pending_applicant_review' | 'pending_issue' | 'issued' | 'active' | 'rejected' | 'returned_for_modification' | 'closed' | 'expired' | 'pending_renewal';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department?: Department;
}

export interface RenewalRecord {
  renewalNumber: number;
  requestedDate: string;
  requestedBy: string;
  approvedDate?: string;
  approvedBy?: string;
  issuedDate?: string;
  issuedBy?: string;
  receiverName: string;
  applicantName: string;
  issuerName?: string;
  signature?: string;
}

export interface ApprovalHistory {
  action: 'created' | 'updated' | 'submitted_for_review' | 'reviewed' | 'submitted_for_issue' | 'issued' | 'rejected' | 'returned' | 'closed' | 'renewal_requested' | 'renewal_approved' | 'renewal_issued' | 'close_requested' | 'close_approved';
  by: string;
  role: UserRole | string;
  timestamp: string;
  comments?: string;
  signature?: string;
  renewalNumber?: number;
}

export interface Permit {
  id: string;
  permitNumber: string;
  type: PermitType;
  status: PermitStatus;
  title: string;
  description: string;
  location: string;
  department: Department;
  workStartDate: string;
  workStartTime: string;
  expectedCompletionDate: string;
  expectedCompletionTime: string;
  expiryDate?: string;
  hazards: string[];
  precautions: string;
  requiredPPE: string[];
  createdBy: string;
  createdAt: string;
  updatedAt?: string;
  receiverName: string;
  receiverDepartment: Department;
  applicantName?: string;
  issuerName?: string;
  approvalHistory: ApprovalHistory[];
  renewalHistory?: RenewalRecord[];
  rejectionReason?: string;
  documents?: string[];
  renewalCount?: number;
  lastRenewalDate?: string;
  lastIssuedDate?: string;
  closedAt?: string;
  closedBy?: string;
}